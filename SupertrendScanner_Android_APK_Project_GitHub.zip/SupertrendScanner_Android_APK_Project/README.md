# Supertrend Scanner Android v1.1

Native Android app for the Supertrend + EMA200 mobile scanner.

## Core scanner (unchanged)
- Binance top-50 USDT markets, minimum $2M quote volume
- 5m / 15m / 1H / 4H Supertrend 3/10 + EMA200
- Near-ST radar sorted by closest ATR distance
- Native alert **only when 5m newly turns `BEAR BRK`**
- Existing BEAR BRK coins are baseline-suppressed on first start
- Same-candle duplicate BEAR BRK alerts are suppressed
- 90-second Android foreground background scanner
- Tap coin/notification to open TradingView 5m
- READY paper tracker remains included

## New in v1.1 — 5m BEAR BRK Forward Tracker
Every real 5m BEAR BRK alert creates a persistent short-side research record for 4 hours.

Recorded fields include:
- entry time / price / Supertrend / EMA200 / ATR
- previous 5m regime before BEAR BRK
- 15m / 1H / 4H regimes at the alert moment
- current short-side return (price down = positive)
- MFE / MAE in percent and entry ATR
- return checkpoints after 5m / 15m / 30m / 1H / 4H
- episode grouping: a repeat alert on the same symbol within 30 minutes is tagged to the same episode
- raw alerts are **not** suppressed by episode grouping

The tracker keeps following an active signal even if the coin later drops out of the scanner's top-50 universe by fetching its 5m candles directly.

### Accuracy rules
- Checkpoint returns use the first fully closed 5m candle at or after each target horizon.
- Entry-candle full high/low is not used for MFE/MAE because part of that candle existed before the alert.
- From the next 5m candle onward, full candle high/low is used, which also lets the tracker reconstruct performance after Android sleeps or the app resumes later.
- Tracking completes when the 4H checkpoint is available; a 6H safety timeout handles missing/delisted data.

## CSV exports
- `mobile_bearbrk_alerts_<timestamp>.csv` — raw BEAR BRK alerts
- `mobile_bearbrk_forward_<timestamp>.csv` — forward outcome tracker
- `supertrend_ready_paper_<timestamp>.csv` — READY paper tracker

## Android background behavior
The app deliberately keeps a low-priority persistent notification while scanning because Android foreground services require one. For reliable monitoring, allow notifications and set Android Battery usage for the app to **Unrestricted**.

## APK build
Use the GitHub Actions workflow in `.github/workflows/build-apk.yml`. It installs Java 17, Android 35 / Build Tools 35.0.0, Gradle 8.9, builds the debug APK and uploads it as a workflow artifact.
