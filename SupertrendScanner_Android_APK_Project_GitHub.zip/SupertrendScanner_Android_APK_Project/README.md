# Supertrend Scanner Android v1

Native Android app for the Supertrend + EMA200 mobile scanner.

## Included
- Binance USDT perpetual top-50 scanner (minimum $2M quote volume)
- 5m / 15m / 1H / 4H Supertrend 3/10 + EMA200
- Near-ST radar sorted by closest ATR distance
- Native alert only when 5m newly turns `BEAR BRK`
- 90-second Android foreground background scanner
- Tap coin/notification to open TradingView 5m
- Local BEAR BRK alert CSV log

The app deliberately keeps a low-priority persistent notification while background scanning is running because Android foreground services require one.


## APK build
GitHub Actions builds an installable debug APK on every push to `main`. This avoids publishing a private release-signing key in the repository. Download the `SupertrendScanner-v1.0-apk` workflow artifact and install `SupertrendScanner-v1.0-debug.apk`.
