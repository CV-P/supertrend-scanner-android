package com.supertrendscanner.mobile;

import java.util.*;

public final class Models {
    private Models() {}

    public static final class MarketItem {
        public String symbol;
        public String base;
        public String market; // PERP / SPOT
        public double quoteVolume;

        public String tradingViewUrl(String interval) {
            String tv = "BINANCE:" + symbol + ("PERP".equals(market) ? ".P" : "");
            String tf;
            switch (interval) {
                case "1m": tf="1"; break; case "3m": tf="3"; break; case "5m": tf="5"; break;
                case "15m": tf="15"; break; case "30m": tf="30"; break; case "1h": tf="60"; break;
                case "2h": tf="120"; break; case "4h": tf="240"; break; case "6h": tf="360"; break;
                case "8h": tf="480"; break; case "12h": tf="720"; break; case "1d": tf="D"; break;
                case "3d": tf="3D"; break; case "1w": tf="W"; break; default: tf="5";
            }
            try { return "https://www.tradingview.com/chart/?symbol=" + java.net.URLEncoder.encode(tv, "UTF-8") + "&interval=" + tf; } catch (Exception e) { return "https://www.tradingview.com/chart/?symbol=" + tv + "&interval=" + tf; }
        }
    }

    public static final class Candle {
        public long openTime;
        public double open, high, low, close;
        public long closeTime;
    }

    public static final class TfResult {
        public String interval;
        public double price, high, low, supertrend, atr, ema;
        public double distanceAtr, distancePct, prevDistanceAtr;
        public Double distanceDelta;
        public String state, prevState;
        public boolean flip;
        public Double flipBreakAtr;
        public boolean momentumConfirm;
        public long barOpenTime, barCloseTime;
        public boolean approaching, receding;
        public String status, candle;
        public boolean rejection;
        public Double recentWickDistanceAtr;
        public Integer recentWickBarsAgo;
        public boolean recentConfirm;
        public String recentConfirmType;
        public Long recentConfirmBarOpenTime;
        public boolean recentFlip;
        public Double recentFlipBreakAtr;
        public Long recentFlipBarOpenTime;
        public String recentFlipCandle;
        public double emaDistanceAtr, emaDistancePct;
        public String emaSlope, structure, regime;
        public boolean aboveEma, stAboveEma, bullContext, bearContext;
    }

    public static final class SymbolResult {
        public MarketItem item;
        public final Map<String,TfResult> tf = new LinkedHashMap<>();
        public String setup = "CONTEXT";
        public String setupSide = "";
        public String setupFamily = "CONTEXT";
        public String setupStage = "CONTEXT";
        public int setupRank = 9;
        public boolean ready;
        public String alertEventId;
        public String error;

        public double closestAtr() {
            double m = Double.POSITIVE_INFINITY;
            for (TfResult t: tf.values()) if (t != null && Double.isFinite(t.distanceAtr)) m = Math.min(m, t.distanceAtr);
            return m;
        }

        public String closestTf() {
            String best=""; double m=Double.POSITIVE_INFINITY;
            for (Map.Entry<String,TfResult> e: tf.entrySet()) {
                TfResult t=e.getValue();
                if (t!=null && Double.isFinite(t.distanceAtr) && t.distanceAtr<m) {m=t.distanceAtr; best=e.getKey();}
            }
            return best;
        }
    }

    public static final class ReadyPaper {
        public String id, symbol, side, family, entryTimeUtc;
        public double entryPrice, atr, currentPrice, mfePct, maePct;
        public long startedMs;
        public boolean active = true;
        public String readyEndedUtc = "";
        public double returnPct() {
            if (entryPrice == 0) return 0;
            double raw=(currentPrice-entryPrice)/entryPrice*100.0;
            return "SHORT".equals(side) ? -raw : raw;
        }
    }
    public static final class BearBrkPaper {
        public String id, symbol, market, previous, entryTimeUtc;
        public String context15m="", context1h="", context4h="";
        public String episodeId="";
        public boolean repeatWithin30m=false;
        public double entryPrice, entrySupertrend, entryEma, atr, currentPrice;
        public double mfePct=0, maePct=0;
        public long startedMs, entryBarOpenMs, lastBarOpenMs;
        public boolean active=true;
        public String completeReason="";
        public Double ret5m, ret15m, ret30m, ret1h, ret4h;

        public double returnPct() {
            if (entryPrice == 0) return 0;
            return (entryPrice-currentPrice)/entryPrice*100.0;
        }
        public double mfeAtr() {
            if (atr <= 0 || entryPrice == 0) return Double.NaN;
            return (mfePct/100.0*entryPrice)/atr;
        }
        public double maeAtr() {
            if (atr <= 0 || entryPrice == 0) return Double.NaN;
            return (maePct/100.0*entryPrice)/atr;
        }
    }

}
