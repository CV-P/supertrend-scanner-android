package com.supertrendscanner.mobile;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;
import static com.supertrendscanner.mobile.Models.*;

public class MainActivity extends Activity {
    private LinearLayout root, nearBox, paperBox, bearBox, alertBox;
    private TextView status, summary, bearSummary;
    private BroadcastReceiver receiver;
    private final int BG=Color.rgb(7,17,29), PANEL=Color.rgb(14,30,45), TEXT=Color.rgb(235,243,250), MUTED=Color.rgb(145,174,199), GREEN=Color.rgb(53,220,160), RED=Color.rgb(255,105,120), BLUE=Color.rgb(78,155,255), AMBER=Color.rgb(245,190,72);

    @Override public void onCreate(Bundle b){super.onCreate(b);buildUi();requestNotif();startScanner();receiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){refreshUi();}};IntentFilter f=new IntentFilter(ScannerService.ACTION_UPDATE);if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,f);refreshUi();}
    @Override protected void onResume(){super.onResume();refreshUi();}
    @Override protected void onDestroy(){try{unregisterReceiver(receiver);}catch(Exception ignored){}super.onDestroy();}

    private void requestNotif(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},42);}
    private void startScanner(){Intent i=new Intent(this,ScannerService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}
    private void action(String a){Intent i=new Intent(this,ScannerService.class);i.setAction(a);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}

    private void buildUi(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(BG);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(14),dp(16),dp(14),dp(30));sc.addView(root,new ScrollView.LayoutParams(-1,-2));setContentView(sc);
        TextView title=text("Crypto Supertrend Scanner",25,Color.WHITE,true);root.addView(title);root.addView(text("Android v1.1 • ST 3/ATR10 + EMA200 • 5m BEAR BRK alerts + forward research",13,MUTED,false));
        status=text("Starting scanner…",14,TEXT,true);status.setPadding(0,dp(10),0,dp(4));root.addView(status);summary=text("",12,MUTED,false);root.addView(summary);
        LinearLayout buttons=new LinearLayout(this);buttons.setOrientation(LinearLayout.HORIZONTAL);buttons.setPadding(0,dp(10),0,dp(10));root.addView(buttons);
        buttons.addView(button("Scan now",v->action(ScannerService.ACTION_SCAN_NOW)),new LinearLayout.LayoutParams(0,dp(48),1));
        buttons.addView(button("Test alert",v->action(ScannerService.ACTION_TEST_ALERT)),new LinearLayout.LayoutParams(0,dp(48),1));
        buttons.addView(button("Battery",v->openBattery()),new LinearLayout.LayoutParams(0,dp(48),1));
        TextView alertMode=text("🔔 ALERT MODE: only when 5m newly turns BEAR BRK",14,AMBER,true);alertMode.setPadding(dp(10),dp(10),dp(10),dp(10));alertMode.setBackgroundColor(PANEL);root.addView(alertMode,new LinearLayout.LayoutParams(-1,-2));

        section("Near Supertrend Radar");root.addView(text("Sorted by closest ATR distance across 5m / 15m / 1H / 4H. Tap a coin to open TradingView 5m.",12,MUTED,false));nearBox=new LinearLayout(this);nearBox.setOrientation(LinearLayout.VERTICAL);root.addView(nearBox);

        section("5m BEAR BRK Forward Tracker");
        root.addView(text("Every real 5m BEAR BRK alert is kept for 4 hours as a SHORT research signal. Positive return/MFE means price moved down after the alert. Re-alerts within 30m are tagged as the same episode, but alerts are not suppressed.",12,MUTED,false));
        bearSummary=text("",12,AMBER,true);bearSummary.setPadding(0,dp(6),0,dp(6));root.addView(bearSummary);
        LinearLayout bearExports=new LinearLayout(this);bearExports.setOrientation(LinearLayout.HORIZONTAL);bearExports.addView(button("Export BEAR tracker CSV",v->exportBearPaper()),new LinearLayout.LayoutParams(0,dp(44),1));bearExports.addView(button("Export raw alert CSV",v->exportAlerts()),new LinearLayout.LayoutParams(0,dp(44),1));root.addView(bearExports);bearBox=new LinearLayout(this);bearBox.setOrientation(LinearLayout.VERTICAL);root.addView(bearBox);

        section("READY Paper Tracker");LinearLayout exports=new LinearLayout(this);exports.setOrientation(LinearLayout.HORIZONTAL);exports.addView(button("Export READY paper CSV",v->exportPaper()),new LinearLayout.LayoutParams(0,dp(44),1));exports.addView(button("Scan now",v->action(ScannerService.ACTION_SCAN_NOW)),new LinearLayout.LayoutParams(0,dp(44),1));root.addView(exports);paperBox=new LinearLayout(this);paperBox.setOrientation(LinearLayout.VERTICAL);root.addView(paperBox);

        section("Recent 5m BEAR BRK Alerts");alertBox=new LinearLayout(this);alertBox.setOrientation(LinearLayout.VERTICAL);root.addView(alertBox);
        root.addView(text("Checkpoint returns use the first fully closed 5m candle at or after 5m / 15m / 30m / 1H / 4H. MFE/MAE uses full candle highs/lows only after the entry candle; the entry candle is handled conservatively so pre-alert movement is not counted. Background scanning uses a foreground service. Keep notifications allowed and Battery usage Unrestricted.",11,MUTED,false));
    }

    private void refreshUi(){runOnUiThread(()->{
        status.setText(ScannerService.STATUS);long age=ScannerService.LAST_SCAN_MS==0?-1:(System.currentTimeMillis()-ScannerService.LAST_SCAN_MS)/1000;summary.setText("50-coin Binance scan • 5m/15m/1H/4H • 90s • last scan "+(age<0?"not finished":age+"s ago")+" • Near ST: "+ScannerService.LAST_NEAR_COUNT);
        renderNear();renderBearPaper();renderPaper();renderAlerts();
    });}

    private void renderNear(){nearBox.removeAllViews();ArrayList<SymbolResult> list=new ArrayList<>(ScannerService.LATEST);list.removeIf(x->x==null||x.item==null||x.error!=null||x.tf.get("5m")==null);list.sort(Comparator.comparingDouble(SymbolResult::closestAtr));int shown=0;
        for(SymbolResult r:list){if(shown>=25)break;if(shown>=12&&r.closestAtr()>1.0)break;shown++;LinearLayout card=card();card.setOnClickListener(v->openUrl(r.item.tradingViewUrl("5m")));
            TextView h=text(r.item.symbol+"  "+r.item.market+"   "+fmtVol(r.item.quoteVolume),16,TEXT,true);card.addView(h);double d=r.closestAtr();String ct=r.closestTf();int c=d<=0.10?GREEN:d<=0.25?BLUE:d<=0.50?AMBER:MUTED;card.addView(text("Closest: "+ct+" • "+f2(d)+" ATR   |   "+r.setup,13,c,true));
            StringBuilder b=new StringBuilder();for(String tf:ScanEngine.TFS){TfResult t=r.tf.get(tf);if(b.length()>0)b.append("   •   ");if(t==null)b.append(tf).append(" ?");else b.append(tf.toUpperCase()).append(" ").append(Indicators.shortRegime(t.regime)).append(" ").append(f2(t.distanceAtr)).append("ATR");}card.addView(text(b.toString(),11,MUTED,false));nearBox.addView(card);
        }
        if(shown==0)nearBox.addView(text("Waiting for the first scan…",13,MUTED,false));
    }

    private void renderBearPaper(){
        bearBox.removeAllViews();ArrayList<BearBrkPaper> p=new ArrayList<>(ScannerService.BEAR_PAPER.values());p.sort((a,b)->Long.compare(b.startedMs,a.startedMs));int active=0,complete=0,repeats=0;HashSet<String>eps=new HashSet<>();for(BearBrkPaper x:p){if(x.active)active++;else complete++;if(x.repeatWithin30m)repeats++;if(x.episodeId!=null&&!x.episodeId.isEmpty())eps.add(x.episodeId);}bearSummary.setText(p.size()+" raw signals • "+eps.size()+" episodes • "+active+" tracking • "+complete+" complete • "+repeats+" repeat≤30m");
        int n=0;for(BearBrkPaper x:p){if(n++>=18)break;LinearLayout c=card();c.setOnClickListener(v->{MarketItem m=new MarketItem();m.symbol=x.symbol;m.market=x.market;openUrl(m.tradingViewUrl("5m"));});int col=x.returnPct()>=0?GREEN:RED;
            c.addView(text((x.active?"TRACKING":"COMPLETE")+" • "+x.symbol+" • "+x.previous+" → BEAR BRK"+(x.repeatWithin30m?" • REPEAT≤30m":""),13,TEXT,true));
            c.addView(text("Entry "+fmt(x.entryPrice)+" → "+fmt(x.currentPrice)+"   SHORT Return "+signed(x.returnPct())+"%",12,col,true));
            c.addView(text("MFE "+signed(x.mfePct)+"% ("+signedFinite(x.mfeAtr())+" ATR)   •   MAE "+signed(x.maePct)+"% ("+signedFinite(x.maeAtr())+" ATR)",11,col,false));
            c.addView(text("5m "+cp(x.ret5m)+"   •   15m "+cp(x.ret15m)+"   •   30m "+cp(x.ret30m)+"   •   1H "+cp(x.ret1h)+"   •   4H "+cp(x.ret4h),11,MUTED,false));
            c.addView(text("HTF at alert: 15m "+safe(x.context15m)+" • 1H "+safe(x.context1h)+" • 4H "+safe(x.context4h),10,MUTED,false));
            c.addView(text(x.entryTimeUtc+" • Episode "+shortEpisode(x.episodeId)+(x.completeReason==null||x.completeReason.isEmpty()?"":" • "+x.completeReason),10,MUTED,false));bearBox.addView(c);
        }
        if(p.isEmpty())bearBox.addView(text("No 5m BEAR BRK signal has fired since this version started.",13,MUTED,false));
    }

    private void renderPaper(){paperBox.removeAllViews();ArrayList<ReadyPaper> p=new ArrayList<>(ScannerService.PAPER.values());p.sort((a,b)->Long.compare(b.startedMs,a.startedMs));int n=0;for(ReadyPaper x:p){if(n++>=15)break;LinearLayout c=card();int col=x.returnPct()>=0?GREEN:RED;c.addView(text((x.active?"TRACKING":"COMPLETE")+" • "+x.symbol+" • "+x.side+" "+x.family,13,TEXT,true));c.addView(text("Entry "+fmt(x.entryPrice)+" → "+fmt(x.currentPrice)+"   Return "+signed(x.returnPct())+"%   MFE "+signed(x.mfePct)+"%   MAE "+signed(x.maePct)+"%",12,col,true));c.addView(text(x.entryTimeUtc+(x.readyEndedUtc.isEmpty()?"":" • READY ended "+x.readyEndedUtc),10,MUTED,false));paperBox.addView(c);}if(p.isEmpty())paperBox.addView(text("No READY signal recorded by the APK yet.",13,MUTED,false));
    }

    private void renderAlerts(){alertBox.removeAllViews();String csv=Storage.readAlertCsv(this);String[] lines=csv.split("\\r?\\n");int start=Math.max(1,lines.length-11);for(int i=lines.length-1;i>=start;i--){String s=lines[i];if(s.trim().isEmpty())continue;alertBox.addView(text(s.replace("\"","").replace(",","  •  "),11,RED,false));}if(lines.length<=1)alertBox.addView(text("No BEAR BRK transition alert has fired yet.",13,MUTED,false));}

    private void exportPaper(){try{String name="supertrend_ready_paper_"+System.currentTimeMillis()+".csv";Storage.exportToDownloads(this,name,Storage.paperCsv(ScannerService.PAPER));Toast.makeText(this,"Saved to Downloads/SupertrendScanner",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    private void exportBearPaper(){try{String name="mobile_bearbrk_forward_"+System.currentTimeMillis()+".csv";Storage.exportToDownloads(this,name,Storage.bearPaperCsv(ScannerService.BEAR_PAPER));Toast.makeText(this,"Saved BEAR tracker to Downloads/SupertrendScanner",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    private void exportAlerts(){try{String name="mobile_bearbrk_alerts_"+System.currentTimeMillis()+".csv";Storage.exportToDownloads(this,name,Storage.readAlertCsv(this));Toast.makeText(this,"Saved to Downloads/SupertrendScanner",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    private void openBattery(){try{Intent i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()));startActivity(i);Toast.makeText(this,"Open Battery → set Unrestricted",Toast.LENGTH_LONG).show();}catch(Exception ignored){}}
    private void openUrl(String u){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){Toast.makeText(this,"No browser found",Toast.LENGTH_SHORT).show();}}

    private void section(String s){TextView t=text(s,18,TEXT,true);t.setPadding(0,dp(18),0,dp(7));root.addView(t);}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(12),dp(10),dp(12),dp(10));c.setBackgroundColor(PANEL);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));c.setLayoutParams(lp);return c;}
    private Button button(String s,View.OnClickListener l){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setTextColor(Color.WHITE);b.setBackgroundColor(Color.rgb(27,86,139));b.setAllCaps(false);b.setOnClickListener(l);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-1);p.setMargins(dp(2),0,dp(2),0);b.setLayoutParams(p);return b;}
    private TextView text(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setLineSpacing(0,1.08f);if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return t;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private static String f2(double x){return Double.isFinite(x)?String.format(Locale.US,"%.2f",x):"—";}
    private static String signed(double x){return String.format(Locale.US,x>=0?"+%.2f":"%.2f",x);}
    private static String signedFinite(double x){return Double.isFinite(x)?signed(x):"—";}
    private static String cp(Double x){return x==null||!Double.isFinite(x)?"—":signed(x)+"%";}
    private static String safe(String s){return s==null||s.isEmpty()?"?":s;}
    private static String shortEpisode(String s){if(s==null||s.isEmpty())return "—";int k=s.lastIndexOf('|');return k>=0&&k<s.length()-1?s.substring(k+1):s;}
    private static String fmt(double v){if(Math.abs(v)>=100)return String.format(Locale.US,"%.2f",v);if(Math.abs(v)>=1)return String.format(Locale.US,"%.4f",v);return String.format(Locale.US,"%.6f",v);}
    private static String fmtVol(double v){if(v>=1e9)return String.format(Locale.US,"$%.1fB",v/1e9);if(v>=1e6)return String.format(Locale.US,"$%.1fM",v/1e6);return String.format(Locale.US,"$%.0f",v);}
}
