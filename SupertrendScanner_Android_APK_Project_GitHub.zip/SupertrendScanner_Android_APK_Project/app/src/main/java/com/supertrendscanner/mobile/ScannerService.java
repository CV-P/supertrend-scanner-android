package com.supertrendscanner.mobile;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import static com.supertrendscanner.mobile.Models.*;

public class ScannerService extends Service {
    public static final String ACTION_UPDATE="com.supertrendscanner.mobile.UPDATE";
    public static final String ACTION_SCAN_NOW="com.supertrendscanner.mobile.SCAN_NOW";
    public static final String ACTION_TEST_ALERT="com.supertrendscanner.mobile.TEST_ALERT";
    public static volatile List<SymbolResult> LATEST=Collections.emptyList();
    public static volatile Map<String,ReadyPaper> PAPER=Collections.emptyMap();
    public static volatile String STATUS="Starting…";
    public static volatile long LAST_SCAN_MS=0;
    public static volatile int LAST_NEAR_COUNT=0;

    private static final String CH_RUN="scanner_running", CH_ALERT="bear_brk_alerts";
    private static final int RUN_ID=1001;
    private final ScheduledExecutorService scheduler=Executors.newSingleThreadScheduledExecutor();
    private final AtomicBoolean scanning=new AtomicBoolean(false);
    private SharedPreferences prefs;
    private LinkedHashMap<String,ReadyPaper> paper;

    @Override public void onCreate(){
        super.onCreate();prefs=getSharedPreferences("scanner",MODE_PRIVATE);paper=new LinkedHashMap<>(Storage.loadPaper(this));PAPER=Collections.unmodifiableMap(new LinkedHashMap<>(paper));createChannels();Notification n=runNote("Starting…");if(Build.VERSION.SDK_INT>=34)startForeground(RUN_ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);else startForeground(RUN_ID,n);scheduler.scheduleWithFixedDelay(this::scanSafe,1,90,TimeUnit.SECONDS);
    }
    @Override public int onStartCommand(Intent i,int flags,int id){String a=i==null?null:i.getAction();if(ACTION_SCAN_NOW.equals(a))scheduler.execute(this::scanSafe);else if(ACTION_TEST_ALERT.equals(a))testAlert();return START_STICKY;}
    @Override public void onDestroy(){scheduler.shutdownNow();super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}

    private void scanSafe(){if(!scanning.compareAndSet(false,true))return;PowerManager.WakeLock wl=null;try{PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);wl=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"SupertrendScanner:scan");wl.acquire(120000);setStatus("Scanning top 50 • 5m / 15m / 1H / 4H…");List<SymbolResult>rows=ScanEngine.scan(50,2_000_000);LATEST=Collections.unmodifiableList(new ArrayList<>(rows));LAST_SCAN_MS=System.currentTimeMillis();int near=0;for(SymbolResult r:rows)if(r!=null&&r.error==null&&r.closestAtr()<=.25)near++;LAST_NEAR_COUNT=near;processBearBrk(rows);processPaper(rows);setStatus("Done • "+rows.size()+" coins • Near ST: "+near+" • next ~90s");}catch(Exception e){setStatus("Scan error • "+e.getClass().getSimpleName()+" • "+String.valueOf(e.getMessage()));}finally{if(wl!=null&&wl.isHeld())wl.release();scanning.set(false);}}

    private void processBearBrk(List<SymbolResult>rows){boolean baseline=prefs.getBoolean("bear_baseline",false);SharedPreferences.Editor ed=prefs.edit();int fired=0;for(SymbolResult r:rows){if(r==null||r.item==null)continue;TfResult t=r.tf.get("5m");if(t==null)continue;String key="regime_"+r.item.symbol,old=prefs.getString(key,null),now=t.regime;if(baseline&&old!=null&&!"BEAR BRK".equals(old)&&"BEAR BRK".equals(now)){long last=prefs.getLong("alert_bar_"+r.item.symbol,-1);if(last!=t.barOpenTime){notifyBear(r.item,old,t,false);Storage.appendAlert(this,r.item.symbol,old,t);ed.putLong("alert_bar_"+r.item.symbol,t.barOpenTime);fired++;}}ed.putString(key,now);}if(!baseline)ed.putBoolean("bear_baseline",true);ed.apply();if(!baseline)STATUS+=" • baseline set";else if(fired>0)STATUS+=" • "+fired+" new BEAR BRK";}

    private void processPaper(List<SymbolResult>rows){long now=System.currentTimeMillis();HashMap<String,SymbolResult>by=new HashMap<>();for(SymbolResult r:rows)if(r!=null&&r.item!=null)by.put(r.item.symbol,r);for(SymbolResult r:rows){if(r==null||!r.ready||r.item==null||r.alertEventId==null)continue;String id=r.item.symbol+"|"+r.alertEventId;if(!paper.containsKey(id)){TfResult t=r.tf.get("5m");if(t==null)continue;ReadyPaper p=new ReadyPaper();p.id=id;p.symbol=r.item.symbol;p.side=r.setupSide;p.family=r.setupFamily;p.entryTimeUtc=Storage.utc(now);p.entryPrice=t.price;p.currentPrice=t.price;p.atr=t.atr;p.startedMs=now;paper.put(id,p);}}
        for(ReadyPaper p:paper.values()){if(!p.active)continue;SymbolResult r=by.get(p.symbol);if(r!=null){TfResult t=r.tf.get("5m");if(t!=null){p.currentPrice=t.price;double x=p.returnPct();p.mfePct=Math.max(p.mfePct,x);p.maePct=Math.min(p.maePct,x);}boolean same=r.ready&&r.alertEventId!=null&&p.id.equals(r.item.symbol+"|"+r.alertEventId);if(!same&&p.readyEndedUtc.isEmpty())p.readyEndedUtc=Storage.utc(now);}if(now-p.startedMs>=4L*60L*60L*1000L)p.active=false;}Storage.savePaper(this,paper);PAPER=Collections.unmodifiableMap(new LinkedHashMap<>(paper));}

    private void createChannels(){if(Build.VERSION.SDK_INT>=26){NotificationManager n=getSystemService(NotificationManager.class);NotificationChannel r=new NotificationChannel(CH_RUN,"Scanner running",NotificationManager.IMPORTANCE_LOW);r.setDescription("Persistent background Supertrend scanning");n.createNotificationChannel(r);NotificationChannel a=new NotificationChannel(CH_ALERT,"5m BEAR BRK alerts",NotificationManager.IMPORTANCE_HIGH);a.setDescription("Only when 5m newly turns BEAR BRK");a.enableVibration(true);a.enableLights(true);a.setLightColor(Color.RED);n.createNotificationChannel(a);}}
    private Notification runNote(String s){PendingIntent p=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CH_RUN):new Notification.Builder(this);return b.setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("Supertrend Scanner running").setContentText(s).setOngoing(true).setContentIntent(p).setCategory(Notification.CATEGORY_SERVICE).build();}
    private void setStatus(String s){STATUS=s;getSystemService(NotificationManager.class).notify(RUN_ID,runNote(s));Intent i=new Intent(ACTION_UPDATE);i.setPackage(getPackageName());sendBroadcast(i);}
    private void notifyBear(MarketItem m,String old,TfResult r,boolean test){String title="⚠ "+m.symbol+" 5m BEAR BRK"+(test?" TEST":""),body=String.format(Locale.US,"5m %s → BEAR BRK • P %.6f • ST %.6f • EMA200 %.6f",old,r.price,r.supertrend,r.ema);PendingIntent p=PendingIntent.getActivity(this,Math.abs(m.symbol.hashCode()),new Intent(Intent.ACTION_VIEW,Uri.parse(m.tradingViewUrl("5m"))),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CH_ALERT):new Notification.Builder(this);Notification n=b.setSmallIcon(android.R.drawable.stat_notify_error).setContentTitle(title).setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setAutoCancel(true).setColor(Color.RED).setContentIntent(p).setPriority(Notification.PRIORITY_HIGH).setCategory(Notification.CATEGORY_ALARM).build();getSystemService(NotificationManager.class).notify(20000+Math.abs((m.symbol+(test?"T":"")).hashCode()%10000),n);}
    private void testAlert(){MarketItem m=new MarketItem();m.symbol="TESTUSDT";m.market="PERP";TfResult t=new TfResult();t.price=100;t.supertrend=101.2;t.ema=100.8;notifyBear(m,"BULL PB",t,true);}
}
