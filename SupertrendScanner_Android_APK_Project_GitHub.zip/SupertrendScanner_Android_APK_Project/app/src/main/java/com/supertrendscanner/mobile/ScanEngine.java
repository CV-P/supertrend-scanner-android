package com.supertrendscanner.mobile;

import java.util.*;
import java.util.concurrent.*;
import static com.supertrendscanner.mobile.Models.*;

public final class ScanEngine {
    public static final String[] TFS={"5m","15m","1h","4h"};
    private static volatile List<MarketItem> cache=Collections.emptyList();private static volatile long cacheTs=0;
    private ScanEngine(){}
    public static List<SymbolResult>scan(int top,double minQuote)throws Exception{long now=System.currentTimeMillis();if(cache.isEmpty()||now-cacheTs>300000){synchronized(ScanEngine.class){if(cache.isEmpty()||now-cacheTs>300000){cache=BinanceApi.universe();cacheTs=now;}}}ArrayList<MarketItem>sel=new ArrayList<>();for(MarketItem m:cache){if(m.quoteVolume>=minQuote){sel.add(m);if(sel.size()>=top)break;}}
        ExecutorService p=Executors.newFixedThreadPool(6);CompletionService<SymbolResult>cs=new ExecutorCompletionService<>(p);for(MarketItem m:sel)cs.submit(()->one(m));ArrayList<SymbolResult>out=new ArrayList<>();for(int i=0;i<sel.size();i++){try{SymbolResult r=cs.take().get();if(r!=null)out.add(r);}catch(Exception ignored){}}p.shutdownNow();out.sort((a,b)->{int q=Integer.compare(a.setupRank,b.setupRank);return q!=0?q:Double.compare(a.closestAtr(),b.closestAtr());});return out;}
    private static SymbolResult one(MarketItem m){SymbolResult r=new SymbolResult();r.item=m;try{for(String tf:TFS){try{r.tf.put(tf,Indicators.analyze(tf,BinanceApi.klines(m,tf,1000),false));}catch(Exception e){r.tf.put(tf,null);}}SetupClassifier.classify(r);return r;}catch(Exception e){r.error=e.getMessage();return r;}}
}
