package com.supertrendscanner.mobile;

import android.content.*;
import android.provider.MediaStore;
import android.net.Uri;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import static com.supertrendscanner.mobile.Models.*;

public final class Storage {
    private Storage(){}
    private static final Object LOCK=new Object();
    private static final String PAPER="ready_paper.json", ALERTS="bearbrk_alerts.csv", BEAR_PAPER="bearbrk_forward.json";

    public static String utc(long ms){
        SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(ms));
    }

    public static Map<String,ReadyPaper>loadPaper(Context c){
        synchronized(LOCK){
            LinkedHashMap<String,ReadyPaper>m=new LinkedHashMap<>();
            File f=new File(c.getFilesDir(),PAPER);if(!f.exists())return m;
            try{
                JSONArray a=new JSONArray(read(f));
                for(int i=0;i<a.length();i++){
                    JSONObject o=a.getJSONObject(i);ReadyPaper p=new ReadyPaper();
                    p.id=o.optString("id");p.symbol=o.optString("symbol");p.side=o.optString("side");p.family=o.optString("family");
                    p.entryTimeUtc=o.optString("entryTimeUtc");p.entryPrice=o.optDouble("entryPrice");p.atr=o.optDouble("atr");
                    p.currentPrice=o.optDouble("currentPrice");p.mfePct=o.optDouble("mfePct");p.maePct=o.optDouble("maePct");
                    p.startedMs=o.optLong("startedMs");p.active=o.optBoolean("active",true);p.readyEndedUtc=o.optString("readyEndedUtc","");
                    m.put(p.id,p);
                }
            }catch(Exception ignored){}
            return m;
        }
    }

    public static void savePaper(Context c,Map<String,ReadyPaper>m){
        synchronized(LOCK){
            try{
                JSONArray a=new JSONArray();
                for(ReadyPaper p:m.values()){
                    JSONObject o=new JSONObject();o.put("id",p.id);o.put("symbol",p.symbol);o.put("side",p.side);o.put("family",p.family);
                    o.put("entryTimeUtc",p.entryTimeUtc);o.put("entryPrice",p.entryPrice);o.put("atr",p.atr);o.put("currentPrice",p.currentPrice);
                    o.put("mfePct",p.mfePct);o.put("maePct",p.maePct);o.put("startedMs",p.startedMs);o.put("active",p.active);o.put("readyEndedUtc",p.readyEndedUtc);a.put(o);
                }
                write(new File(c.getFilesDir(),PAPER),a.toString());
            }catch(Exception ignored){}
        }
    }

    public static Map<String,BearBrkPaper>loadBearPaper(Context c){
        synchronized(LOCK){
            LinkedHashMap<String,BearBrkPaper>m=new LinkedHashMap<>();
            File f=new File(c.getFilesDir(),BEAR_PAPER);if(!f.exists())return m;
            try{
                JSONArray a=new JSONArray(read(f));
                for(int i=0;i<a.length();i++){
                    JSONObject o=a.getJSONObject(i);BearBrkPaper p=new BearBrkPaper();
                    p.id=o.optString("id");p.symbol=o.optString("symbol");p.market=o.optString("market","PERP");p.previous=o.optString("previous");
                    p.entryTimeUtc=o.optString("entryTimeUtc");p.context15m=o.optString("context15m","");p.context1h=o.optString("context1h","");p.context4h=o.optString("context4h","");
                    p.episodeId=o.optString("episodeId",p.id);p.repeatWithin30m=o.optBoolean("repeatWithin30m",false);
                    p.entryPrice=o.optDouble("entryPrice");p.entrySupertrend=o.optDouble("entrySupertrend");p.entryEma=o.optDouble("entryEma");p.atr=o.optDouble("atr");p.currentPrice=o.optDouble("currentPrice");
                    p.mfePct=o.optDouble("mfePct",0);p.maePct=o.optDouble("maePct",0);p.startedMs=o.optLong("startedMs");p.entryBarOpenMs=o.optLong("entryBarOpenMs");p.lastBarOpenMs=o.optLong("lastBarOpenMs",p.entryBarOpenMs);
                    p.active=o.optBoolean("active",true);p.completeReason=o.optString("completeReason","");
                    p.ret5m=optD(o,"ret5m");p.ret15m=optD(o,"ret15m");p.ret30m=optD(o,"ret30m");p.ret1h=optD(o,"ret1h");p.ret4h=optD(o,"ret4h");
                    m.put(p.id,p);
                }
            }catch(Exception ignored){}
            return m;
        }
    }

    public static void saveBearPaper(Context c,Map<String,BearBrkPaper>m){
        synchronized(LOCK){
            try{
                JSONArray a=new JSONArray();
                for(BearBrkPaper p:m.values()){
                    JSONObject o=new JSONObject();o.put("id",p.id);o.put("symbol",p.symbol);o.put("market",p.market);o.put("previous",p.previous);o.put("entryTimeUtc",p.entryTimeUtc);
                    o.put("context15m",p.context15m);o.put("context1h",p.context1h);o.put("context4h",p.context4h);o.put("episodeId",p.episodeId);o.put("repeatWithin30m",p.repeatWithin30m);
                    o.put("entryPrice",p.entryPrice);o.put("entrySupertrend",p.entrySupertrend);o.put("entryEma",p.entryEma);o.put("atr",p.atr);o.put("currentPrice",p.currentPrice);
                    o.put("mfePct",p.mfePct);o.put("maePct",p.maePct);o.put("startedMs",p.startedMs);o.put("entryBarOpenMs",p.entryBarOpenMs);o.put("lastBarOpenMs",p.lastBarOpenMs);
                    o.put("active",p.active);o.put("completeReason",p.completeReason);putD(o,"ret5m",p.ret5m);putD(o,"ret15m",p.ret15m);putD(o,"ret30m",p.ret30m);putD(o,"ret1h",p.ret1h);putD(o,"ret4h",p.ret4h);a.put(o);
                }
                write(new File(c.getFilesDir(),BEAR_PAPER),a.toString());
            }catch(Exception ignored){}
        }
    }

    public static void appendAlert(Context c,String sym,String prev,TfResult t){
        synchronized(LOCK){
            try{
                File f=new File(c.getFilesDir(),ALERTS);boolean fresh=!f.exists();
                try(FileOutputStream os=new FileOutputStream(f,true)){
                    if(fresh)os.write("time_utc,symbol,previous,new_state,price,supertrend,ema200,atr,bar_open_ms\n".getBytes(StandardCharsets.UTF_8));
                    String s=q(utc(System.currentTimeMillis()))+","+q(sym)+","+q(prev)+",BEAR BRK,"+t.price+","+t.supertrend+","+t.ema+","+t.atr+","+t.barOpenTime+"\n";
                    os.write(s.getBytes(StandardCharsets.UTF_8));
                }
            }catch(Exception ignored){}
        }
    }

    public static String readAlertCsv(Context c){
        try{File f=new File(c.getFilesDir(),ALERTS);return f.exists()?read(f):"time_utc,symbol,previous,new_state,price,supertrend,ema200,atr,bar_open_ms\n";}catch(Exception e){return "";}
    }

    public static String paperCsv(Map<String,ReadyPaper>m){
        StringBuilder b=new StringBuilder("id,symbol,side,family,entry_time_utc,entry_price,current_price,return_pct,mfe_pct,mae_pct,atr,status\n");
        for(ReadyPaper p:m.values())b.append(q(p.id)).append(',').append(q(p.symbol)).append(',').append(q(p.side)).append(',').append(q(p.family)).append(',').append(q(p.entryTimeUtc)).append(',').append(p.entryPrice).append(',').append(p.currentPrice).append(',').append(p.returnPct()).append(',').append(p.mfePct).append(',').append(p.maePct).append(',').append(p.atr).append(',').append(p.active?"TRACKING":"COMPLETE").append('\n');
        return b.toString();
    }

    public static String bearPaperCsv(Map<String,BearBrkPaper>m){
        StringBuilder b=new StringBuilder("id,episode_id,repeat_within_30m,symbol,market,previous,new_state,entry_time_utc,entry_bar_open_ms,entry_price,entry_supertrend,entry_ema200,entry_atr,context_15m,context_1h,context_4h,current_price,short_return_pct,mfe_pct,mae_pct,mfe_atr,mae_atr,ret_5m_pct,ret_15m_pct,ret_30m_pct,ret_1h_pct,ret_4h_pct,status,complete_reason\n");
        for(BearBrkPaper p:m.values()){
            b.append(q(p.id)).append(',').append(q(p.episodeId)).append(',').append(p.repeatWithin30m).append(',').append(q(p.symbol)).append(',').append(q(p.market)).append(',').append(q(p.previous)).append(",BEAR BRK,").append(q(p.entryTimeUtc)).append(',').append(p.entryBarOpenMs).append(',').append(p.entryPrice).append(',').append(p.entrySupertrend).append(',').append(p.entryEma).append(',').append(p.atr).append(',').append(q(p.context15m)).append(',').append(q(p.context1h)).append(',').append(q(p.context4h)).append(',').append(p.currentPrice).append(',').append(p.returnPct()).append(',').append(p.mfePct).append(',').append(p.maePct).append(',').append(p.mfeAtr()).append(',').append(p.maeAtr()).append(',').append(csvD(p.ret5m)).append(',').append(csvD(p.ret15m)).append(',').append(csvD(p.ret30m)).append(',').append(csvD(p.ret1h)).append(',').append(csvD(p.ret4h)).append(',').append(p.active?"TRACKING":"COMPLETE").append(',').append(q(p.completeReason)).append('\n');
        }
        return b.toString();
    }

    public static Uri exportToDownloads(Context c,String name,String content)throws Exception{
        ContentValues v=new ContentValues();v.put(MediaStore.MediaColumns.DISPLAY_NAME,name);v.put(MediaStore.MediaColumns.MIME_TYPE,"text/csv");v.put(MediaStore.MediaColumns.RELATIVE_PATH,"Download/SupertrendScanner");
        Uri u=c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(u==null)throw new IOException("create export failed");
        try(OutputStream os=c.getContentResolver().openOutputStream(u)){os.write(content.getBytes(StandardCharsets.UTF_8));}
        return u;
    }

    private static Double optD(JSONObject o,String k){if(!o.has(k)||o.isNull(k))return null;double v=o.optDouble(k,Double.NaN);return Double.isFinite(v)?v:null;}
    private static void putD(JSONObject o,String k,Double v)throws JSONException{if(v==null||!Double.isFinite(v))o.put(k,JSONObject.NULL);else o.put(k,v);}
    private static String csvD(Double v){return v==null||!Double.isFinite(v)?"":String.valueOf(v);}
    private static String q(String s){if(s==null)return "";return "\""+s.replace("\"","\"\"")+"\"";}
    private static String read(File f)throws Exception{try(FileInputStream in=new FileInputStream(f);ByteArrayOutputStream o=new ByteArrayOutputStream()){byte[]b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);return o.toString("UTF-8");}}
    private static void write(File f,String s)throws Exception{try(FileOutputStream o=new FileOutputStream(f)){o.write(s.getBytes(StandardCharsets.UTF_8));}}
}
