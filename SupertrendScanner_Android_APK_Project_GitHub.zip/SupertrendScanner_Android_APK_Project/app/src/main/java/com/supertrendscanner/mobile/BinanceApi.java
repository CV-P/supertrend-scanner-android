package com.supertrendscanner.mobile;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import static com.supertrendscanner.mobile.Models.*;

public final class BinanceApi {
    private BinanceApi() {}
    private static final String FUT="https://fapi.binance.com", SPOT="https://api.binance.com";
    private static final Set<String> EXCLUDED=new HashSet<>(Arrays.asList("USDC","FDUSD","TUSD","USDP","DAI","BUSD","USDE","PYUSD","EUR","TRY","BRL","AUD","GBP","UAH","RUB","NGN","ZAR"));
    private static String get(String u)throws Exception{Exception last=null;for(int a=0;a<3;a++){try{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setRequestProperty("User-Agent","SupertrendScannerAndroid/1.0");c.setRequestProperty("Accept","application/json");int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();ByteArrayOutputStream b=new ByteArrayOutputStream();byte[]buf=new byte[8192];int n;while((n=in.read(buf))!=-1)b.write(buf,0,n);String s=b.toString(StandardCharsets.UTF_8.name());in.close();c.disconnect();if(code>=200&&code<300)return s;throw new IOException("HTTP "+code);}catch(Exception e){last=e;if(a<2)Thread.sleep(500L*(1L<<a));}}throw last;}
    public static List<MarketItem> universe()throws Exception{LinkedHashMap<String,MarketItem>m=new LinkedHashMap<>();Exception fe=null,se=null;try{JSONObject info=new JSONObject(get(FUT+"/fapi/v1/exchangeInfo"));Map<String,Double>v=volumes(new JSONArray(get(FUT+"/fapi/v1/ticker/24hr")));JSONArray a=info.getJSONArray("symbols");for(int i=0;i<a.length();i++){JSONObject s=a.getJSONObject(i);String sym=s.optString("symbol"),base=s.optString("baseAsset");if("TRADING".equals(s.optString("status"))&&"PERPETUAL".equals(s.optString("contractType"))&&"USDT".equals(s.optString("quoteAsset"))&&!EXCLUDED.contains(base)){MarketItem x=new MarketItem();x.symbol=sym;x.base=base;x.market="PERP";x.quoteVolume=v.getOrDefault(sym,0.0);m.put(sym,x);}}}catch(Exception e){fe=e;}
        try{JSONObject info=new JSONObject(get(SPOT+"/api/v3/exchangeInfo"));Map<String,Double>v=volumes(new JSONArray(get(SPOT+"/api/v3/ticker/24hr")));JSONArray a=info.getJSONArray("symbols");for(int i=0;i<a.length();i++){JSONObject s=a.getJSONObject(i);String sym=s.optString("symbol"),base=s.optString("baseAsset");if("TRADING".equals(s.optString("status"))&&"USDT".equals(s.optString("quoteAsset"))&&!EXCLUDED.contains(base)&&!m.containsKey(sym)){MarketItem x=new MarketItem();x.symbol=sym;x.base=base;x.market="SPOT";x.quoteVolume=v.getOrDefault(sym,0.0);m.put(sym,x);}}}catch(Exception e){se=e;}
        if(m.isEmpty())throw new IOException("Binance unavailable: "+fe+" / "+se);ArrayList<MarketItem>out=new ArrayList<>(m.values());out.sort((a,b)->Double.compare(b.quoteVolume,a.quoteVolume));return out;}
    private static Map<String,Double>volumes(JSONArray a){HashMap<String,Double>m=new HashMap<>();for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)m.put(x.optString("symbol"),x.optDouble("quoteVolume",0));}return m;}
    public static List<Candle>klines(MarketItem m,String tf,int limit)throws Exception{String base="PERP".equals(m.market)?FUT+"/fapi/v1/klines":SPOT+"/api/v3/klines";String u=base+"?symbol="+URLEncoder.encode(m.symbol,"UTF-8")+"&interval="+tf+"&limit="+limit;JSONArray a=new JSONArray(get(u));ArrayList<Candle>out=new ArrayList<>(a.length());for(int i=0;i<a.length();i++){JSONArray x=a.getJSONArray(i);Candle c=new Candle();c.openTime=x.getLong(0);c.open=Double.parseDouble(x.getString(1));c.high=Double.parseDouble(x.getString(2));c.low=Double.parseDouble(x.getString(3));c.close=Double.parseDouble(x.getString(4));c.closeTime=x.getLong(6);out.add(c);}return out;}
}
