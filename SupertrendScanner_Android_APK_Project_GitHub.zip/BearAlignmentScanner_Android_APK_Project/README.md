# ST Bear Align Lab — Android v1.0

This is a separate Android application from the earlier **Supertrend Scanner**. Its package/application ID is different, so both APKs can be installed on the same Android device at the same time.

## Exact alert rule

A real alert is created only when both conditions are true:

1. **15m Supertrend is already BEAR** — current 15m ST state is BEAR **and the previous 15m candle ST state was also BEAR**.
2. **5m Supertrend freshly flips BULL → BEAR** on the live/current 5m candle.

The same 5m trigger candle is alerted only once.

Indicator settings are unchanged from the research scanner:

- Supertrend factor: **3.0**
- ATR length: **10**
- EMA regime: **200**
- Scan universe: top **50** Binance USDT markets by 24h quote volume, minimum **$2M**
- Scan interval: approximately **90 seconds**
- Timeframes calculated: **5m / 15m / 1H / 4H**

## Forward paper trade created for every alert

Each real alert creates one simulated **SHORT at the observed market price**. No broker order is placed.

Two stop-loss scenarios are tracked independently from the same entry:

- **SL5** = the locked **5m bearish Supertrend** value at signal time.
- **SL15** = the locked **15m bearish Supertrend** value at signal time.

The primary TP is designed as a practical **near-1H-Supertrend** target:

- **TP NEAR 1H ST** = locked 1H ST + `0.25 × locked 1H ATR`.
- It is used only when that level is below the short entry price.
- The app also records the stricter `0.10 × 1H ATR` proximity zone and an **exact 1H ST touch**.

This allows the data to answer both questions:

- Which stop is better: 5m ST or 15m ST?
- How often does price get near the 1H ST, very near it, or actually touch it?

## Anti-hindsight handling

- SL and primary TP levels are **locked at signal time** for fair forward comparison.
- The live entry candle does **not** use its entire high/low because part of that candle existed before the signal.
- On the entry candle, only post-signal live price samples are used.
- From the next 5m candle onward, full high/low data is used.
- If a later 5m candle touches both SL and TP, the result is **AMBIG** rather than guessing which occurred first.
- Tracking continues for **4 hours** even after a stop is hit, so 1H-ST approach/touch behavior is still measured.

## Data recorded

The forward tracker stores:

- entry price/time
- 5m / 15m / 1H ST and ATR at entry
- 1H and 4H context at entry
- SL5 and SL15 risk percentages
- near-1H-ST TP price and reward
- RR using SL5 and SL15
- current short return
- MFE / MAE and MFE / MAE in 5m ATR
- 5m / 15m / 30m / 1H / 2H / 4H returns
- SL5 result and SL15 result independently
- closest distance to the **locked 1H ST** in ATR and %
- whether price reached ≤0.25 ATR, ≤0.10 ATR, or touched the locked 1H ST
- maximum penetration beyond the locked 1H ST
- current/dynamic 1H ST and the closest sampled distance to it

CSV exports are saved to:

`Downloads/STBearAlignLab`

Files:

- `bear_align_forward_<timestamp>.csv`
- `bear_align_alerts_<timestamp>.csv`

## Android background behavior

The app uses an Android foreground service. For the most reliable background scanning:

- allow notifications
- set Android battery usage for **ST Bear Align Lab** to **Unrestricted**

The persistent service notification is expected while scanning is active.
