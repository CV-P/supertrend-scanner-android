package com.supertrendscanner.bearalign;

import java.util.*;

public final class Models {
    private Models() {}

    public static final class MarketItem {
        public String symbol;
        public String base;
        public String market; // PERP / SPOT
        public double quoteVolume;

        public String tradingViewUrl(String interval) {
            String tv = "BINANCE:" + symbol + ("PERP".equals(market) ? ".P" : "");
            String tf;
            switch (interval) {
                case "1m": tf="1"; break; case "3m": tf="3"; break; case "5m": tf="5"; break;
                case "15m": tf="15"; break; case "30m": tf="30"; break; case "1h": tf="60"; break;
                case "2h": tf="120"; break; case "4h": tf="240"; break; case "6h": tf="360"; break;
                case "8h": tf="480"; break; case "12h": tf="720"; break; case "1d": tf="D"; break;
                case "3d": tf="3D"; break; case "1w": tf="W"; break; default: tf="5";
            }
            try { return "https://www.tradingview.com/chart/?symbol=" + java.net.URLEncoder.encode(tv, "UTF-8") + "&interval=" + tf; }
            catch (Exception e) { return "https://www.tradingview.com/chart/?symbol=" + tv + "&interval=" + tf; }
        }
    }

    public static final class Candle {
        public long openTime;
        public double open, high, low, close;
        public long closeTime;
    }

    public static final class TfResult {
        public String interval;
        public double price, high, low, supertrend, atr, ema;
        public double distanceAtr, distancePct, prevDistanceAtr;
        public Double distanceDelta;
        public String state, prevState;
        public boolean flip;
        public Double flipBreakAtr;
        public boolean momentumConfirm;
        public long barOpenTime, barCloseTime;
        public boolean approaching, receding;
        public String status, candle;
        public boolean rejection;
        public Double recentWickDistanceAtr;
        public Integer recentWickBarsAgo;
        public boolean recentConfirm;
        public String recentConfirmType;
        public Long recentConfirmBarOpenTime;
        public boolean recentFlip;
        public Double recentFlipBreakAtr;
        public Long recentFlipBarOpenTime;
        public String recentFlipCandle;
        public double emaDistanceAtr, emaDistancePct;
        public String emaSlope, structure, regime;
        public boolean aboveEma, stAboveEma, bullContext, bearContext;
    }

    public static final class SymbolResult {
        public MarketItem item;
        public final Map<String,TfResult> tf = new LinkedHashMap<>();
        public String setup = "CONTEXT";
        public String setupSide = "";
        public String setupFamily = "CONTEXT";
        public String setupStage = "CONTEXT";
        public int setupRank = 9;
        public boolean ready;
        public String alertEventId;
        public String error;

        public double closestAtr() {
            double m = Double.POSITIVE_INFINITY;
            for (TfResult t: tf.values()) if (t != null && Double.isFinite(t.distanceAtr)) m = Math.min(m, t.distanceAtr);
            return m;
        }
        public String closestTf() {
            String best=""; double m=Double.POSITIVE_INFINITY;
            for (Map.Entry<String,TfResult> e: tf.entrySet()) {
                TfResult t=e.getValue();
                if (t!=null && Double.isFinite(t.distanceAtr) && t.distanceAtr<m) {m=t.distanceAtr; best=e.getKey();}
            }
            return best;
        }
    }

    /**
     * One paper SHORT opened when:
     *   15m Supertrend is already BEAR (current + previous 15m candle BEAR), and
     *   the live 5m Supertrend freshly flips BULL -> BEAR.
     *
     * Two independent exit scenarios are evaluated from the same market entry:
     *   A) fixed SL = 5m ST at signal time
     *   B) fixed SL = 15m ST at signal time
     * Both use the locked 1h ST at signal time as the nominal TP only when it is below entry.
     */
    public static final class AlignShortPaper {
        public String id="", symbol="", market="PERP", entryTimeUtc="";
        public long startedMs, entry5mBarOpenMs, last5mBarOpenMs;

        public double entryPrice;
        public double entry5mSt, entry15mSt, entry1hSt;
        public double entry5mAtr, entry15mAtr, entry1hAtr;
        public String entry5mPrevState="", entry5mState="";
        public String entry15mPrevState="", entry15mState="";
        public String entry1hState="", entry1hRegime="", entry4hRegime="";
        public boolean target1hValid;

        public double currentPrice;
        public double current1hSt;
        public double current1hAtr;
        public String current1hState="", current1hRegime="";

        public double mfePct=0.0; // favorable for SHORT = price down
        public double maePct=0.0; // adverse for SHORT = negative

        public Double closestStatic1hAtr=null;
        public Double closestStatic1hPct=null;
        public Double closestDynamic1hAtr=null;
        public Double closestDynamic1hPct=null;
        public boolean nearStatic025=false, nearStatic010=false, static1hTouched=false;
        public boolean nearDynamic025=false, nearDynamic010=false, dynamic1hTouched=false;
        public double maxBeyondStatic1hAtr=0.0;

        public String sl5Outcome="OPEN", sl15Outcome="OPEN"; // OPEN / TP / SL / AMBIG / TIME
        public String sl5ResolvedUtc="", sl15ResolvedUtc="";
        public Double sl5ExitPrice=null, sl15ExitPrice=null;
        public Double sl5ReturnPct=null, sl15ReturnPct=null;

        public Double ret5m=null, ret15m=null, ret30m=null, ret1h=null, ret2h=null, ret4h=null;
        public boolean active=true;
        public String completeReason="";

        public double returnPct(){
            if(entryPrice<=0||currentPrice<=0)return 0;
            return (entryPrice-currentPrice)/entryPrice*100.0;
        }
        public double mfeAtr5(){
            if(entry5mAtr<=0||entryPrice<=0)return Double.NaN;
            return (mfePct/100.0*entryPrice)/entry5mAtr;
        }
        public double maeAtr5(){
            if(entry5mAtr<=0||entryPrice<=0)return Double.NaN;
            return (maePct/100.0*entryPrice)/entry5mAtr;
        }
        public double sl5RiskPct(){return entryPrice>0?(entry5mSt-entryPrice)/entryPrice*100.0:Double.NaN;}
        public double sl15RiskPct(){return entryPrice>0?(entry15mSt-entryPrice)/entryPrice*100.0:Double.NaN;}
        /** Primary paper TP = 0.25 x locked 1H ATR before the locked 1H ST (front-run / NEAR zone). */
        public double tpNear025Price(){return entry1hSt>0&&entry1hAtr>0?entry1hSt+0.25*entry1hAtr:Double.NaN;}
        public double tpNear010Price(){return entry1hSt>0&&entry1hAtr>0?entry1hSt+0.10*entry1hAtr:Double.NaN;}
        public double target1hRewardPct(){double tp=tpNear025Price();return target1hValid&&entryPrice>0&&Double.isFinite(tp)?(entryPrice-tp)/entryPrice*100.0:Double.NaN;}
        public double rr5(){double r=sl5RiskPct(),w=target1hRewardPct();return r>0&&Double.isFinite(w)?w/r:Double.NaN;}
        public double rr15(){double r=sl15RiskPct(),w=target1hRewardPct();return r>0&&Double.isFinite(w)?w/r:Double.NaN;}
    }
}
