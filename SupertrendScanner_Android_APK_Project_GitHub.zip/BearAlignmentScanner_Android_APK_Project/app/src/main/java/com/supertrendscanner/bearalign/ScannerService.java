package com.supertrendscanner.bearalign;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import static com.supertrendscanner.bearalign.Models.*;

public class ScannerService extends Service {
    public static final String ACTION_UPDATE="com.supertrendscanner.bearalign.UPDATE";
    public static final String ACTION_SCAN_NOW="com.supertrendscanner.bearalign.SCAN_NOW";
    public static final String ACTION_TEST_ALERT="com.supertrendscanner.bearalign.TEST_ALERT";
    public static volatile List<SymbolResult> LATEST=Collections.emptyList();
    public static volatile Map<String,AlignShortPaper> TRACKS=Collections.emptyMap();
    public static volatile String STATUS="Starting…";
    public static volatile long LAST_SCAN_MS=0;
    public static volatile int LAST_NEAR_COUNT=0;
    public static volatile int LAST_SIGNAL_COUNT=0;

    private static final String CH_RUN="bear_align_running", CH_ALERT="bear_align_signal_alerts";
    private static final int RUN_ID=3101;
    private static final long MIN=60L*1000L, HOUR=60L*MIN;
    private final ScheduledExecutorService scheduler=Executors.newSingleThreadScheduledExecutor();
    private final AtomicBoolean scanning=new AtomicBoolean(false);
    private SharedPreferences prefs;
    private LinkedHashMap<String,AlignShortPaper> tracks;

    @Override public void onCreate(){
        super.onCreate();
        prefs=getSharedPreferences("bear_align_scanner",MODE_PRIVATE);
        tracks=new LinkedHashMap<>(Storage.loadTracks(this));
        TRACKS=Collections.unmodifiableMap(new LinkedHashMap<>(tracks));
        createChannels();
        Notification n=runNote("Starting…");
        if(Build.VERSION.SDK_INT>=34)startForeground(RUN_ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);else startForeground(RUN_ID,n);
        scheduler.scheduleWithFixedDelay(this::scanSafe,1,90,TimeUnit.SECONDS);
    }

    @Override public int onStartCommand(Intent i,int flags,int id){
        String a=i==null?null:i.getAction();
        if(ACTION_SCAN_NOW.equals(a))scheduler.execute(this::scanSafe);else if(ACTION_TEST_ALERT.equals(a))testAlert();
        return START_STICKY;
    }
    @Override public void onDestroy(){scheduler.shutdownNow();super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}

    private void scanSafe(){
        if(!scanning.compareAndSet(false,true))return;
        PowerManager.WakeLock wl=null;
        try{
            PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
            wl=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"STBearAlign:scan");wl.acquire(150000);
            setStatus("Scanning top 50 • looking for 15m BEAR + fresh 5m BEAR flip…");
            List<SymbolResult> rows=ScanEngine.scan(50,2_000_000);
            LATEST=Collections.unmodifiableList(new ArrayList<>(rows));LAST_SCAN_MS=System.currentTimeMillis();
            int near=0;for(SymbolResult r:rows)if(r!=null&&r.error==null&&r.closestAtr()<=.25)near++;LAST_NEAR_COUNT=near;
            int fired=processSignals(rows);LAST_SIGNAL_COUNT=fired;
            processForward();
            int active=0;for(AlignShortPaper p:tracks.values())if(p.active)active++;
            setStatus("Done • "+rows.size()+" coins • Near ST: "+near+" • Forward: "+active+(fired>0?" • "+fired+" NEW SIGNAL":"")+" • next ~90s");
        }catch(Exception e){
            setStatus("Scan error • "+e.getClass().getSimpleName()+" • "+String.valueOf(e.getMessage()));
        }finally{
            if(wl!=null&&wl.isHeld())wl.release();scanning.set(false);
        }
    }

    /** Exact alert rule requested: 15m ST is already bearish, then 5m freshly flips bearish. */
    private boolean signalRule(SymbolResult r){
        if(r==null||r.item==null)return false;
        TfResult t5=r.tf.get("5m"),t15=r.tf.get("15m");
        if(t5==null||t15==null)return false;
        boolean fifteenAlreadyBear="BEAR".equals(t15.state)&&"BEAR".equals(t15.prevState);
        boolean fiveFreshBear=t5.flip&&"BEAR".equals(t5.state)&&"BULL".equals(t5.prevState);
        return fifteenAlreadyBear&&fiveFreshBear;
    }

    private int processSignals(List<SymbolResult> rows){
        int fired=0;long now=System.currentTimeMillis();SharedPreferences.Editor ed=prefs.edit();
        for(SymbolResult r:rows){
            if(!signalRule(r))continue;
            TfResult t5=r.tf.get("5m");
            String key="alert_bar_"+r.item.symbol;
            long last=prefs.getLong(key,-1);
            if(last==t5.barOpenTime)continue; // same 5m candle cannot alert twice
            AlignShortPaper p=startTrack(r,now);
            if(p!=null){
                notifySignal(r.item,p,false);Storage.appendAlert(this,p);ed.putLong(key,t5.barOpenTime);fired++;
            }
        }
        ed.apply();Storage.saveTracks(this,tracks);TRACKS=Collections.unmodifiableMap(new LinkedHashMap<>(tracks));
        return fired;
    }

    private AlignShortPaper startTrack(SymbolResult r,long now){
        TfResult t5=r.tf.get("5m"),t15=r.tf.get("15m"),t1=r.tf.get("1h"),t4=r.tf.get("4h");
        if(t5==null||t15==null||t1==null)return null;
        String id=r.item.symbol+"|15B_5FLIP|"+t5.barOpenTime;
        if(tracks.containsKey(id))return null;
        AlignShortPaper p=new AlignShortPaper();
        p.id=id;p.symbol=r.item.symbol;p.market=r.item.market;p.entryTimeUtc=Storage.utc(now);p.startedMs=now;p.entry5mBarOpenMs=t5.barOpenTime;p.last5mBarOpenMs=t5.barOpenTime;
        p.entryPrice=t5.price;p.currentPrice=t5.price;
        p.entry5mSt=t5.supertrend;p.entry15mSt=t15.supertrend;p.entry1hSt=t1.supertrend;
        p.entry5mAtr=t5.atr;p.entry15mAtr=t15.atr;p.entry1hAtr=t1.atr;
        p.entry5mPrevState=t5.prevState;p.entry5mState=t5.state;p.entry15mPrevState=t15.prevState;p.entry15mState=t15.state;
        p.entry1hState=t1.state;p.entry1hRegime=t1.regime;p.entry4hRegime=t4==null?"":t4.regime;
        p.target1hValid=t1.supertrend>0&&t1.atr>0&&(t1.supertrend+0.25*t1.atr)<t5.price;
        p.current1hSt=t1.supertrend;p.current1hAtr=t1.atr;p.current1hState=t1.state;p.current1hRegime=t1.regime;
        updateExcursion(p,p.entryPrice);updateStaticApproachPoint(p,p.entryPrice);updateDynamicApproachPoint(p,p.entryPrice,t1.supertrend,t1.atr);
        tracks.put(id,p);return p;
    }

    private void processForward(){
        long now=System.currentTimeMillis();
        LinkedHashMap<String,List<AlignShortPaper>> groups=new LinkedHashMap<>();
        for(AlignShortPaper p:tracks.values()){
            if(!p.active)continue;
            String k=(p.market==null||p.market.isEmpty()?"PERP":p.market)+"|"+p.symbol;
            groups.computeIfAbsent(k,x->new ArrayList<>()).add(p);
        }
        for(List<AlignShortPaper> group:groups.values()){
            AlignShortPaper first=group.get(0);
            try{
                MarketItem m=new MarketItem();m.symbol=first.symbol;m.market=first.market==null||first.market.isEmpty()?"PERP":first.market;
                List<Candle> k5=BinanceApi.klines(m,"5m",150);
                TfResult dyn1=null;
                try{dyn1=Indicators.analyze("1h",BinanceApi.klines(m,"1h",320),false);}catch(Exception ignored){}
                for(AlignShortPaper p:group)updateTrack(p,k5,dyn1,now);
            }catch(Exception e){
                for(AlignShortPaper p:group){
                    if(now-p.startedMs>=6L*HOUR){finishTimeout(p,now);p.active=false;p.completeReason="TIMEOUT_NO_4H_DATA";}
                }
            }
        }
        Storage.saveTracks(this,tracks);TRACKS=Collections.unmodifiableMap(new LinkedHashMap<>(tracks));
    }

    private void updateTrack(AlignShortPaper p,List<Candle> k5,TfResult dyn1,long now){
        if(k5==null||k5.isEmpty())return;
        Candle last=k5.get(k5.size()-1);p.currentPrice=last.close;p.last5mBarOpenMs=last.openTime;
        if(dyn1!=null){p.current1hSt=dyn1.supertrend;p.current1hAtr=dyn1.atr;p.current1hState=dyn1.state;p.current1hRegime=dyn1.regime;}

        // Current live sample is safe even on the entry bar because it is observed after the signal.
        updateExcursion(p,p.currentPrice);updateStaticApproachPoint(p,p.currentPrice);
        if(dyn1!=null)updateDynamicApproachPoint(p,p.currentPrice,dyn1.supertrend,dyn1.atr);
        resolveByPoint(p,p.currentPrice,now);

        // Full OHLC is used only for bars that opened after the signal bar, avoiding pre-entry contamination.
        for(Candle c:k5){
            if(c.openTime<=p.entry5mBarOpenMs)continue;
            if(c.openTime>now)break;
            updateExcursion(p,c.low);updateExcursion(p,c.high);
            updateStaticApproachRange(p,c.low,c.high);
            resolveByBar(p,c);
        }

        if(dyn1!=null){
            if(last.openTime>p.entry5mBarOpenMs)updateDynamicApproachRange(p,last.low,last.high,dyn1.supertrend,dyn1.atr);
            else updateDynamicApproachPoint(p,p.currentPrice,dyn1.supertrend,dyn1.atr);
        }

        if(p.ret5m==null)p.ret5m=checkpoint(p,k5,now,5L*MIN);
        if(p.ret15m==null)p.ret15m=checkpoint(p,k5,now,15L*MIN);
        if(p.ret30m==null)p.ret30m=checkpoint(p,k5,now,30L*MIN);
        if(p.ret1h==null)p.ret1h=checkpoint(p,k5,now,HOUR);
        if(p.ret2h==null)p.ret2h=checkpoint(p,k5,now,2L*HOUR);
        if(p.ret4h==null)p.ret4h=checkpoint(p,k5,now,4L*HOUR);

        if(p.ret4h!=null){
            double px=checkpointPrice(p,k5,now,4L*HOUR);
            if(px<=0)px=p.currentPrice;
            resolveTimeIfOpen(p,px,now);
            p.active=false;p.completeReason="4H_COMPLETE";
        }else if(now-p.startedMs>=6L*HOUR){
            finishTimeout(p,now);p.active=false;p.completeReason="TIMEOUT_NO_4H";
        }
    }

    private void updateExcursion(AlignShortPaper p,double px){
        if(px<=0||p.entryPrice<=0)return;
        double r=(p.entryPrice-px)/p.entryPrice*100.0;
        p.mfePct=Math.max(p.mfePct,r);p.maePct=Math.min(p.maePct,r);
    }

    private void updateStaticApproachPoint(AlignShortPaper p,double px){
        if(p.entry1hSt<=0||p.entry1hAtr<=0||px<=0)return;
        double dist=Math.abs(px-p.entry1hSt), atr=dist/p.entry1hAtr, pct=dist/p.entryPrice*100.0;
        p.closestStatic1hAtr=min(p.closestStatic1hAtr,atr);p.closestStatic1hPct=min(p.closestStatic1hPct,pct);
        if(atr<=.25)p.nearStatic025=true;if(atr<=.10)p.nearStatic010=true;
        if(dist<=Math.max(p.entryPrice*0.000001,1e-12))p.static1hTouched=true;
        if(p.target1hValid&&px<p.entry1hSt)p.maxBeyondStatic1hAtr=Math.max(p.maxBeyondStatic1hAtr,(p.entry1hSt-px)/p.entry1hAtr);
    }

    private void updateStaticApproachRange(AlignShortPaper p,double low,double high){
        if(p.entry1hSt<=0||p.entry1hAtr<=0)return;
        double target=p.entry1hSt,dist;
        if(low<=target&&high>=target){dist=0;p.static1hTouched=true;}
        else dist=Math.min(Math.abs(low-target),Math.abs(high-target));
        double atr=dist/p.entry1hAtr,pct=dist/p.entryPrice*100.0;
        p.closestStatic1hAtr=min(p.closestStatic1hAtr,atr);p.closestStatic1hPct=min(p.closestStatic1hPct,pct);
        if(atr<=.25)p.nearStatic025=true;if(atr<=.10)p.nearStatic010=true;
        if(p.target1hValid&&low<=target){p.static1hTouched=true;p.maxBeyondStatic1hAtr=Math.max(p.maxBeyondStatic1hAtr,(target-low)/p.entry1hAtr);}
    }

    private void updateDynamicApproachPoint(AlignShortPaper p,double px,double st,double atrBase){
        if(px<=0||st<=0||atrBase<=0)return;double d=Math.abs(px-st),a=d/atrBase,pc=d/p.entryPrice*100.0;
        p.closestDynamic1hAtr=min(p.closestDynamic1hAtr,a);p.closestDynamic1hPct=min(p.closestDynamic1hPct,pc);if(a<=.25)p.nearDynamic025=true;if(a<=.10)p.nearDynamic010=true;
        if(d<=Math.max(p.entryPrice*0.000001,1e-12))p.dynamic1hTouched=true;
    }

    private void updateDynamicApproachRange(AlignShortPaper p,double low,double high,double st,double atrBase){
        if(st<=0||atrBase<=0)return;double d;if(low<=st&&high>=st){d=0;p.dynamic1hTouched=true;}else d=Math.min(Math.abs(low-st),Math.abs(high-st));double a=d/atrBase,pc=d/p.entryPrice*100.0;
        p.closestDynamic1hAtr=min(p.closestDynamic1hAtr,a);p.closestDynamic1hPct=min(p.closestDynamic1hPct,pc);if(a<=.25)p.nearDynamic025=true;if(a<=.10)p.nearDynamic010=true;
    }

    private Double min(Double old,double v){return old==null||!Double.isFinite(old)||v<old?v:old;}

    /** Entry-bar sampled price only. */
    private void resolveByPoint(AlignShortPaper p,double px,long now){
        if("OPEN".equals(p.sl5Outcome))resolvePointOne(p,true,p.entry5mSt,px,now);
        if("OPEN".equals(p.sl15Outcome))resolvePointOne(p,false,p.entry15mSt,px,now);
    }
    private void resolvePointOne(AlignShortPaper p,boolean five,double sl,double px,long now){
        double tpPx=p.tpNear025Price();boolean stop=sl>0&&px>=sl, tp=p.target1hValid&&Double.isFinite(tpPx)&&px<=tpPx;
        if(!stop&&!tp)return;
        if(stop&&tp)resolve(p,five,"AMBIG",px,now);else if(stop)resolve(p,five,"SL",sl,now);else resolve(p,five,"TP",tpPx,now);
    }

    /** Chronological full 5m bars after the entry bar. */
    private void resolveByBar(AlignShortPaper p,Candle c){
        if("OPEN".equals(p.sl5Outcome))resolveBarOne(p,true,p.entry5mSt,c);
        if("OPEN".equals(p.sl15Outcome))resolveBarOne(p,false,p.entry15mSt,c);
    }
    private void resolveBarOne(AlignShortPaper p,boolean five,double sl,Candle c){
        double tpPx=p.tpNear025Price();boolean stop=sl>0&&c.high>=sl, tp=p.target1hValid&&Double.isFinite(tpPx)&&c.low<=tpPx;
        if(!stop&&!tp)return;
        long when=Math.min(c.closeTime,System.currentTimeMillis());
        if(stop&&tp)resolve(p,five,"AMBIG",c.close,when);else if(stop)resolve(p,five,"SL",sl,when);else resolve(p,five,"TP",tpPx,when);
    }

    private void resolve(AlignShortPaper p,boolean five,String outcome,double exit,long when){
        boolean ambiguous="AMBIG".equals(outcome);
        Double exitPx=ambiguous?null:(exit>0?exit:null);
        Double ret=exitPx==null?null:(p.entryPrice-exitPx)/p.entryPrice*100.0;
        if(five){p.sl5Outcome=outcome;p.sl5ResolvedUtc=Storage.utc(when);p.sl5ExitPrice=exitPx;p.sl5ReturnPct=ret;}
        else{p.sl15Outcome=outcome;p.sl15ResolvedUtc=Storage.utc(when);p.sl15ExitPrice=exitPx;p.sl15ReturnPct=ret;}
    }

    private void resolveTimeIfOpen(AlignShortPaper p,double px,long now){
        if("OPEN".equals(p.sl5Outcome))resolve(p,true,"TIME",px,now);
        if("OPEN".equals(p.sl15Outcome))resolve(p,false,"TIME",px,now);
    }
    private void finishTimeout(AlignShortPaper p,long now){resolveTimeIfOpen(p,p.currentPrice,now);}

    private Double checkpoint(AlignShortPaper p,List<Candle> ks,long now,long horizon){
        double px=checkpointPrice(p,ks,now,horizon);if(px<=0)return null;return (p.entryPrice-px)/p.entryPrice*100.0;
    }
    private double checkpointPrice(AlignShortPaper p,List<Candle> ks,long now,long horizon){
        long target=p.startedMs+horizon;if(now<target)return -1;
        for(Candle c:ks)if(c.closeTime>=target&&c.closeTime<=now&&c.close>0)return c.close;
        return -1;
    }

    private void createChannels(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager n=getSystemService(NotificationManager.class);
            NotificationChannel r=new NotificationChannel(CH_RUN,"Bear alignment scanner running",NotificationManager.IMPORTANCE_LOW);r.setDescription("Persistent 15m bearish + 5m fresh bearish Supertrend scanning");n.createNotificationChannel(r);
            NotificationChannel a=new NotificationChannel(CH_ALERT,"15m BEAR + fresh 5m BEAR alerts",NotificationManager.IMPORTANCE_HIGH);a.setDescription("Alerts only when 15m ST is already bearish and 5m ST freshly flips bearish");a.enableVibration(true);a.enableLights(true);a.setLightColor(Color.RED);n.createNotificationChannel(a);
        }
    }
    private Notification runNote(String s){
        PendingIntent p=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CH_RUN):new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("ST Bear Align Lab running").setContentText(s).setOngoing(true).setContentIntent(p).setCategory(Notification.CATEGORY_SERVICE).build();
    }
    private void setStatus(String s){STATUS=s;getSystemService(NotificationManager.class).notify(RUN_ID,runNote(s));Intent i=new Intent(ACTION_UPDATE);i.setPackage(getPackageName());sendBroadcast(i);}

    private void notifySignal(MarketItem m,AlignShortPaper p,boolean test){
        String title="🔻 "+m.symbol+" 15m BEAR + 5m FRESH BEAR"+(test?" TEST":"");
        String target=p.target1hValid?String.format(Locale.US,"TP near 1H ST %.6f (ST %.6f)",p.tpNear025Price(),p.entry1hSt):String.format(Locale.US,"1H ST %.6f (no downside near-target)",p.entry1hSt);
        String body=String.format(Locale.US,"SHORT %.6f • SL5 %.6f • SL15 %.6f • %s",p.entryPrice,p.entry5mSt,p.entry15mSt,target);
        PendingIntent pi=PendingIntent.getActivity(this,Math.abs((m.symbol+"BA").hashCode()),new Intent(Intent.ACTION_VIEW,Uri.parse(m.tradingViewUrl("5m"))),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CH_ALERT):new Notification.Builder(this);
        Notification n=b.setSmallIcon(android.R.drawable.stat_notify_error).setContentTitle(title).setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setAutoCancel(true).setColor(Color.RED).setContentIntent(pi).setPriority(Notification.PRIORITY_HIGH).setCategory(Notification.CATEGORY_ALARM).build();
        getSystemService(NotificationManager.class).notify(41000+Math.abs((m.symbol+(test?"T":"")).hashCode()%10000),n);
    }

    private void testAlert(){
        MarketItem m=new MarketItem();m.symbol="TESTUSDT";m.market="PERP";
        AlignShortPaper p=new AlignShortPaper();p.entryPrice=100;p.entry5mSt=101.2;p.entry15mSt=102.4;p.entry1hSt=96.5;p.target1hValid=true;
        notifySignal(m,p,true);
    }
}
