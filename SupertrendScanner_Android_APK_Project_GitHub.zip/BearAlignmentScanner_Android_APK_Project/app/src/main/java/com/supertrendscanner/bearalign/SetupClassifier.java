package com.supertrendscanner.bearalign;

import static com.supertrendscanner.bearalign.Models.*;

public final class SetupClassifier {
    private SetupClassifier() {}
    public static final double APPROACH=.50, EARLY=1.00, EXPIRY=1.50, FLIP_MAX=1.00;

    public static void classify(SymbolResult r){
        TfResult tr=r.tf.get("5m"), en=r.tf.get("15m"), h1=r.tf.get("1h"), h4=r.tf.get("4h");
        if(tr==null||en==null||h1==null||h4==null){set(r,"MISSING TF DATA","","NONE","CONTEXT",8);return;}
        boolean hBull=h1.bullContext&&h4.bullContext, hBear=h1.bearContext&&h4.bearContext;
        boolean sBull="BULL TREND".equals(h1.regime)&&"BULL TREND".equals(h4.regime)&&("RISING".equals(h1.emaSlope)||"RISING".equals(h4.emaSlope));
        boolean sBear="BEAR TREND".equals(h1.regime)&&"BEAR TREND".equals(h4.regime)&&("FALLING".equals(h1.emaSlope)||"FALLING".equals(h4.emaSlope));
        boolean enBull="BULL TREND".equals(en.regime), enBear="BEAR TREND".equals(en.regime);
        boolean enBullPb="BULL PB".equals(en.regime)&&!"FALLING".equals(en.emaSlope);
        boolean enBearRally="BEAR RALLY".equals(en.regime)&&!"RISING".equals(en.emaSlope);
        Double wd=en.recentWickDistanceAtr; Integer ago=en.recentWickBarsAgo;
        boolean notExpired=Double.isFinite(en.distanceAtr)&&en.distanceAtr<=EXPIRY;
        boolean approach=wd!=null&&wd<=APPROACH&&notExpired, early=wd!=null&&wd<=EARLY&&notExpired;
        boolean earlyToward=early&&(en.approaching||(ago!=null&&ago>0));
        boolean trBull="BULL".equals(tr.state)&&tr.recentConfirm, trBear="BEAR".equals(tr.state)&&tr.recentConfirm;
        Double fb=tr.recentFlipBreakAtr; boolean flipOk=fb!=null&&fb>=0&&fb<=FLIP_MAX;
        boolean freshLong=sBull&&tr.recentFlip&&"BULL".equals(tr.state)&&"BULL".equals(tr.recentFlipCandle)&&tr.aboveEma&&!"FALLING".equals(tr.emaSlope)&&enBull&&"RISING".equals(en.emaSlope)&&flipOk;
        boolean freshShort=sBear&&tr.recentFlip&&"BEAR".equals(tr.state)&&"BEAR".equals(tr.recentFlipCandle)&&!tr.aboveEma&&!"RISING".equals(tr.emaSlope)&&enBear&&"FALLING".equals(en.emaSlope)&&flipOk;
        if(sBull&&enBull&&approach&&trBull)ready(r,"READY LONG • PULLBACK","LONG","PULLBACK",tr.recentConfirmBarOpenTime);
        else if(sBear&&enBear&&approach&&trBear)ready(r,"READY SHORT • PULLBACK","SHORT","PULLBACK",tr.recentConfirmBarOpenTime);
        else if(freshLong)ready(r,"READY LONG • FRESH FLIP","LONG","FRESH_FLIP",tr.recentFlipBarOpenTime);
        else if(freshShort)ready(r,"READY SHORT • FRESH FLIP","SHORT","FRESH_FLIP",tr.recentFlipBarOpenTime);
        else if(sBull&&enBull&&approach)set(r,"A+ LONG WATCH","LONG","PULLBACK","WATCH",1);
        else if(sBear&&enBear&&approach)set(r,"A+ SHORT WATCH","SHORT","PULLBACK","WATCH",1);
        else if(sBull&&enBullPb&&early)set(r,"DEEP LONG WATCH","LONG","PULLBACK","WATCH",2);
        else if(sBear&&enBearRally&&early)set(r,"DEEP SHORT WATCH","SHORT","PULLBACK","WATCH",2);
        else if(sBull&&enBull&&earlyToward)set(r,"EARLY LONG WATCH","LONG","PULLBACK","WATCH",3);
        else if(sBear&&enBear&&earlyToward)set(r,"EARLY SHORT WATCH","SHORT","PULLBACK","WATCH",3);
        else if(hBull)set(r,"BULL CONTEXT","LONG","CONTEXT","CONTEXT",4);
        else if(hBear)set(r,"BEAR CONTEXT","SHORT","CONTEXT","CONTEXT",4);
        else if(has(r,"BULL PB"))set(r,"BULL PULLBACK","LONG","CONTEXT","CONTEXT",6);
        else if(has(r,"BEAR RALLY"))set(r,"BEAR RALLY","SHORT","CONTEXT","CONTEXT",6);
        else set(r,"MIXED","","NONE","CONTEXT",9);
    }
    private static boolean has(SymbolResult r,String s){for(TfResult t:r.tf.values())if(t!=null&&s.equals(t.regime))return true;return false;}
    private static void ready(SymbolResult r,String setup,String side,String fam,Long bar){set(r,setup,side,fam,"READY",0);r.ready=true;r.alertEventId=side+"|"+fam+"|"+(bar==null?0:bar);}
    private static void set(SymbolResult r,String s,String side,String fam,String stage,int rank){r.setup=s;r.setupSide=side;r.setupFamily=fam;r.setupStage=stage;r.setupRank=rank;r.ready=false;}
}
