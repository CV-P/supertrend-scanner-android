package com.supertrendscanner.bearalign;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;
import static com.supertrendscanner.bearalign.Models.*;

public class MainActivity extends Activity {
    private LinearLayout root, nearBox, trackBox, alertBox;
    private TextView status, summary, trackSummary;
    private BroadcastReceiver receiver;
    private final int BG=Color.rgb(7,17,29), PANEL=Color.rgb(14,30,45), TEXT=Color.rgb(235,243,250), MUTED=Color.rgb(145,174,199), GREEN=Color.rgb(53,220,160), RED=Color.rgb(255,105,120), BLUE=Color.rgb(78,155,255), AMBER=Color.rgb(245,190,72), PURPLE=Color.rgb(190,145,255);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);buildUi();requestNotif();startScanner();
        receiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){refreshUi();}};
        IntentFilter f=new IntentFilter(ScannerService.ACTION_UPDATE);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,f);
        refreshUi();
    }
    @Override protected void onResume(){super.onResume();refreshUi();}
    @Override protected void onDestroy(){try{unregisterReceiver(receiver);}catch(Exception ignored){}super.onDestroy();}

    private void requestNotif(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},42);}
    private void startScanner(){Intent i=new Intent(this,ScannerService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}
    private void action(String a){Intent i=new Intent(this,ScannerService.class);i.setAction(a);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}

    private void buildUi(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackgroundColor(BG);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(14),dp(16),dp(14),dp(30));sc.addView(root,new ScrollView.LayoutParams(-1,-2));setContentView(sc);

        root.addView(text("ST Bear Align Lab",25,Color.WHITE,true));
        root.addView(text("Separate Android app • 15m bearish ST + fresh 5m bearish ST flip • dual-SL forward paper test",13,MUTED,false));
        status=text("Starting scanner…",14,TEXT,true);status.setPadding(0,dp(10),0,dp(4));root.addView(status);
        summary=text("",12,MUTED,false);root.addView(summary);

        LinearLayout buttons=new LinearLayout(this);buttons.setOrientation(LinearLayout.HORIZONTAL);buttons.setPadding(0,dp(10),0,dp(10));root.addView(buttons);
        buttons.addView(button("Scan now",v->action(ScannerService.ACTION_SCAN_NOW)),new LinearLayout.LayoutParams(0,dp(48),1));
        buttons.addView(button("Test alert",v->action(ScannerService.ACTION_TEST_ALERT)),new LinearLayout.LayoutParams(0,dp(48),1));
        buttons.addView(button("Battery",v->openBattery()),new LinearLayout.LayoutParams(0,dp(48),1));

        TextView alertMode=text("🔔 ALERT ONLY: 15m ST already BEAR + 5m ST freshly flips BULL → BEAR",14,AMBER,true);alertMode.setPadding(dp(10),dp(10),dp(10),dp(10));alertMode.setBackgroundColor(PANEL);root.addView(alertMode,new LinearLayout.LayoutParams(-1,-2));
        root.addView(text("Strict '15m already bearish' = both the current and previous 15m Supertrend states are BEAR. A 5m signal is fresh only when the current 5m Supertrend flips from BULL to BEAR. Same-candle re-alerts are suppressed.",11,MUTED,false));

        section("Near Supertrend Radar");
        root.addView(text("Sorted by closest ATR distance across 5m / 15m / 1H / 4H. Tap a coin to open TradingView 5m.",12,MUTED,false));
        nearBox=new LinearLayout(this);nearBox.setOrientation(LinearLayout.VERTICAL);root.addView(nearBox);

        section("Forward Paper Trades — Every Alert");
        root.addView(text("Each alert opens one simulated SHORT at the observed market price. Two exit scenarios are tracked independently: SL at the locked 5m bearish ST and SL at the locked 15m bearish ST. Both use a practical TP at the locked 1H-ST NEAR zone (0.25 x 1H ATR before the locked ST) when that target is below entry. The tracker also measures how close price gets to the locked and live/dynamic 1H ST, even if a stop is hit first.",12,MUTED,false));
        trackSummary=text("",12,AMBER,true);trackSummary.setPadding(0,dp(6),0,dp(6));root.addView(trackSummary);
        LinearLayout exports=new LinearLayout(this);exports.setOrientation(LinearLayout.HORIZONTAL);
        exports.addView(button("Export forward CSV",v->exportTracks()),new LinearLayout.LayoutParams(0,dp(44),1));
        exports.addView(button("Export raw alerts",v->exportAlerts()),new LinearLayout.LayoutParams(0,dp(44),1));root.addView(exports);
        trackBox=new LinearLayout(this);trackBox.setOrientation(LinearLayout.VERTICAL);root.addView(trackBox);

        section("Recent Alignment Alerts");alertBox=new LinearLayout(this);alertBox.setOrientation(LinearLayout.VERTICAL);root.addView(alertBox);
        root.addView(text("Research notes: SL and TP levels are locked at signal time so the two stop methods can be compared fairly. The entry candle uses only live post-signal samples; full 5m candle highs/lows are used from the next candle onward. If a later 5m candle touches both TP and SL, the scenario is marked AMBIG rather than guessing the intrabar order. Tracking continues to 4H even after an SL so we can still study 1H-ST approach/touch behavior.",11,MUTED,false));
    }

    private void refreshUi(){runOnUiThread(()->{
        status.setText(ScannerService.STATUS);
        long age=ScannerService.LAST_SCAN_MS==0?-1:(System.currentTimeMillis()-ScannerService.LAST_SCAN_MS)/1000;
        summary.setText("Top-50 Binance • 5m/15m/1H/4H • ~90s • last scan "+(age<0?"not finished":age+"s ago")+" • Near ST: "+ScannerService.LAST_NEAR_COUNT);
        renderNear();renderTracks();renderAlerts();
    });}

    private void renderNear(){
        nearBox.removeAllViews();ArrayList<SymbolResult> list=new ArrayList<>(ScannerService.LATEST);
        list.removeIf(x->x==null||x.item==null||x.error!=null||x.tf.get("5m")==null);
        list.sort(Comparator.comparingDouble(SymbolResult::closestAtr));int shown=0;
        for(SymbolResult r:list){
            if(shown>=25)break;if(shown>=12&&r.closestAtr()>1.0)break;shown++;
            LinearLayout card=card();card.setOnClickListener(v->openUrl(r.item.tradingViewUrl("5m")));
            card.addView(text(r.item.symbol+"  "+r.item.market+"   "+fmtVol(r.item.quoteVolume),16,TEXT,true));
            boolean match=isSignalNow(r);String lead=match?"⚡ SIGNAL NOW   ":"";int c=match?RED:(r.closestAtr()<=.10?GREEN:r.closestAtr()<=.25?BLUE:r.closestAtr()<=.50?AMBER:MUTED);
            card.addView(text(lead+"Closest: "+r.closestTf()+" • "+f2(r.closestAtr())+" ATR",13,c,true));
            StringBuilder b=new StringBuilder();for(String tf:ScanEngine.TFS){TfResult t=r.tf.get(tf);if(b.length()>0)b.append("   •   ");if(t==null)b.append(tf).append(" ?");else b.append(tf.toUpperCase()).append(" ").append(t.state).append("/").append(Indicators.shortRegime(t.regime)).append(" ").append(f2(t.distanceAtr)).append("ATR");}card.addView(text(b.toString(),11,MUTED,false));
            nearBox.addView(card);
        }
        if(shown==0)nearBox.addView(text("Waiting for the first scan…",13,MUTED,false));
    }

    private boolean isSignalNow(SymbolResult r){
        TfResult t5=r.tf.get("5m"),t15=r.tf.get("15m");
        return t5!=null&&t15!=null&&"BEAR".equals(t15.state)&&"BEAR".equals(t15.prevState)&&t5.flip&&"BEAR".equals(t5.state)&&"BULL".equals(t5.prevState);
    }

    private void renderTracks(){
        trackBox.removeAllViews();ArrayList<AlignShortPaper> list=new ArrayList<>(ScannerService.TRACKS.values());list.sort((a,b)->Long.compare(b.startedMs,a.startedMs));
        int active=0,complete=0,tp5=0,sl5=0,tp15=0,sl15=0,touch=0,near25=0,valid=0;
        for(AlignShortPaper p:list){
            if(p.active)active++;else complete++;if("TP".equals(p.sl5Outcome))tp5++;if("SL".equals(p.sl5Outcome))sl5++;if("TP".equals(p.sl15Outcome))tp15++;if("SL".equals(p.sl15Outcome))sl15++;if(p.static1hTouched)touch++;if(p.nearStatic025)near25++;if(p.target1hValid)valid++;
        }
        trackSummary.setText(list.size()+" signals • "+active+" tracking • "+complete+" complete • 1H target valid "+valid+" • near≤0.25ATR "+near25+" • touched "+touch+"\nSL5: TP "+tp5+" / SL "+sl5+"   •   SL15: TP "+tp15+" / SL "+sl15);
        int n=0;for(AlignShortPaper p:list){if(n++>=20)break;LinearLayout c=card();c.setOnClickListener(v->{MarketItem m=new MarketItem();m.symbol=p.symbol;m.market=p.market;openUrl(m.tradingViewUrl("5m"));});
            int retCol=p.returnPct()>=0?GREEN:RED;
            c.addView(text((p.active?"TRACKING":"COMPLETE")+" • "+p.symbol+" • 15m BEAR already + 5m FRESH BEAR",13,TEXT,true));
            c.addView(text("SHORT "+fmt(p.entryPrice)+" → "+fmt(p.currentPrice)+"   Return "+signed(p.returnPct())+"%   MFE "+signed(p.mfePct)+"%   MAE "+signed(p.maePct)+"%",12,retCol,true));
            c.addView(text("SL5 "+fmt(p.entry5mSt)+" (risk "+pct(p.sl5RiskPct())+")   →   "+outcome(p.sl5Outcome,p.sl5ReturnPct),11,outcomeColor(p.sl5Outcome),true));
            c.addView(text("SL15 "+fmt(p.entry15mSt)+" (risk "+pct(p.sl15RiskPct())+")  →   "+outcome(p.sl15Outcome,p.sl15ReturnPct),11,outcomeColor(p.sl15Outcome),true));
            String tp=p.target1hValid?"TP NEAR 1H ST "+fmt(p.tpNear025Price())+" (locked ST "+fmt(p.entry1hSt)+", reward "+pct(p.target1hRewardPct())+", RR5 "+f2(p.rr5())+", RR15 "+f2(p.rr15())+")":"Locked 1H ST "+fmt(p.entry1hSt)+" has no valid downside 0.25-ATR near-target";
            c.addView(text(tp,11,p.target1hValid?PURPLE:AMBER,true));
            c.addView(text("Locked 1H ST approach: closest "+dAtr(p.closestStatic1hAtr)+" • near≤0.25 "+yn(p.nearStatic025)+" • near≤0.10 "+yn(p.nearStatic010)+" • touch "+yn(p.static1hTouched)+(p.maxBeyondStatic1hAtr>0?" • beyond "+f2(p.maxBeyondStatic1hAtr)+" ATR":""),11,MUTED,false));
            c.addView(text("Live 1H ST: "+fmt(p.current1hSt)+" • "+safe(p.current1hState)+"/"+safe(p.current1hRegime)+" • closest "+dAtr(p.closestDynamic1hAtr)+" • touch "+yn(p.dynamic1hTouched),11,MUTED,false));
            c.addView(text("5m "+cp(p.ret5m)+" • 15m "+cp(p.ret15m)+" • 30m "+cp(p.ret30m)+" • 1H "+cp(p.ret1h)+" • 2H "+cp(p.ret2h)+" • 4H "+cp(p.ret4h),11,MUTED,false));
            c.addView(text("At entry: 5m "+safe(p.entry5mPrevState)+"→"+safe(p.entry5mState)+" • 15m "+safe(p.entry15mPrevState)+"→"+safe(p.entry15mState)+" • 1H "+safe(p.entry1hState)+"/"+safe(p.entry1hRegime)+" • 4H "+safe(p.entry4hRegime),10,MUTED,false));
            c.addView(text(p.entryTimeUtc+(p.completeReason.isEmpty()?"":" • "+p.completeReason),10,MUTED,false));trackBox.addView(c);
        }
        if(list.isEmpty())trackBox.addView(text("No alignment signal has fired since this app was installed.",13,MUTED,false));
    }

    private int outcomeColor(String s){if("TP".equals(s))return GREEN;if("SL".equals(s))return RED;if("AMBIG".equals(s))return AMBER;if("TIME".equals(s))return BLUE;return MUTED;}
    private String outcome(String s,Double r){return s+(r==null?"":" ("+signed(r)+"%)");}

    private void renderAlerts(){
        alertBox.removeAllViews();String csv=Storage.readAlertCsv(this);String[] lines=csv.split("\\r?\\n");int start=Math.max(1,lines.length-11);
        for(int i=lines.length-1;i>=start;i--){String s=lines[i];if(s.trim().isEmpty())continue;alertBox.addView(text(s.replace("\"","").replace(",","  •  "),10,RED,false));}
        if(lines.length<=1)alertBox.addView(text("No alignment alert has fired yet.",13,MUTED,false));
    }

    private void exportTracks(){try{String name="bear_align_forward_"+System.currentTimeMillis()+".csv";Storage.exportToDownloads(this,name,Storage.trackCsv(ScannerService.TRACKS));Toast.makeText(this,"Saved to Downloads/STBearAlignLab",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    private void exportAlerts(){try{String name="bear_align_alerts_"+System.currentTimeMillis()+".csv";Storage.exportToDownloads(this,name,Storage.readAlertCsv(this));Toast.makeText(this,"Saved to Downloads/STBearAlignLab",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    private void openBattery(){try{Intent i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()));startActivity(i);Toast.makeText(this,"Open Battery → set Unrestricted",Toast.LENGTH_LONG).show();}catch(Exception ignored){}}
    private void openUrl(String u){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){Toast.makeText(this,"No browser found",Toast.LENGTH_SHORT).show();}}

    private void section(String s){TextView t=text(s,18,TEXT,true);t.setPadding(0,dp(18),0,dp(7));root.addView(t);}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(12),dp(10),dp(12),dp(10));c.setBackgroundColor(PANEL);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));c.setLayoutParams(lp);return c;}
    private Button button(String s,View.OnClickListener l){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setTextColor(Color.WHITE);b.setBackgroundColor(Color.rgb(27,86,139));b.setAllCaps(false);b.setOnClickListener(l);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-1);p.setMargins(dp(2),0,dp(2),0);b.setLayoutParams(p);return b;}
    private TextView text(String s,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setLineSpacing(0,1.08f);if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return t;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private static String f2(double x){return Double.isFinite(x)?String.format(Locale.US,"%.2f",x):"—";}
    private static String signed(double x){return String.format(Locale.US,x>=0?"+%.2f":"%.2f",x);}
    private static String pct(double x){return Double.isFinite(x)?signed(x)+"%":"—";}
    private static String cp(Double x){return x==null||!Double.isFinite(x)?"—":signed(x)+"%";}
    private static String dAtr(Double x){return x==null||!Double.isFinite(x)?"—":String.format(Locale.US,"%.2f ATR",x);}
    private static String yn(boolean x){return x?"YES":"NO";}
    private static String safe(String s){return s==null||s.isEmpty()?"?":s;}
    private static String fmt(double v){if(!Double.isFinite(v)||v==0)return "—";if(Math.abs(v)>=100)return String.format(Locale.US,"%.2f",v);if(Math.abs(v)>=1)return String.format(Locale.US,"%.4f",v);return String.format(Locale.US,"%.6f",v);}
    private static String fmtVol(double v){if(v>=1e9)return String.format(Locale.US,"$%.1fB",v/1e9);if(v>=1e6)return String.format(Locale.US,"$%.1fM",v/1e6);return String.format(Locale.US,"$%.0f",v);}
}
