package com.supertrendscanner.bearalign;

import android.content.*;
import android.net.Uri;
import android.provider.MediaStore;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import static com.supertrendscanner.bearalign.Models.*;

public final class Storage {
    private Storage(){}
    private static final Object LOCK=new Object();
    private static final String TRACK="bear_align_forward.json";
    private static final String ALERTS="bear_align_alerts.csv";

    public static String utc(long ms){
        SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(ms));
    }

    public static Map<String,AlignShortPaper> loadTracks(Context c){
        synchronized(LOCK){
            LinkedHashMap<String,AlignShortPaper> out=new LinkedHashMap<>();
            File f=new File(c.getFilesDir(),TRACK); if(!f.exists())return out;
            try{
                JSONArray a=new JSONArray(read(f));
                for(int i=0;i<a.length();i++){
                    JSONObject o=a.getJSONObject(i); AlignShortPaper p=new AlignShortPaper();
                    p.id=o.optString("id",""); p.symbol=o.optString("symbol",""); p.market=o.optString("market","PERP"); p.entryTimeUtc=o.optString("entryTimeUtc","");
                    p.startedMs=o.optLong("startedMs"); p.entry5mBarOpenMs=o.optLong("entry5mBarOpenMs"); p.last5mBarOpenMs=o.optLong("last5mBarOpenMs",p.entry5mBarOpenMs);
                    p.entryPrice=o.optDouble("entryPrice"); p.entry5mSt=o.optDouble("entry5mSt"); p.entry15mSt=o.optDouble("entry15mSt"); p.entry1hSt=o.optDouble("entry1hSt");
                    p.entry5mAtr=o.optDouble("entry5mAtr"); p.entry15mAtr=o.optDouble("entry15mAtr"); p.entry1hAtr=o.optDouble("entry1hAtr");
                    p.entry5mPrevState=o.optString("entry5mPrevState",""); p.entry5mState=o.optString("entry5mState",""); p.entry15mPrevState=o.optString("entry15mPrevState",""); p.entry15mState=o.optString("entry15mState","");
                    p.entry1hState=o.optString("entry1hState",""); p.entry1hRegime=o.optString("entry1hRegime",""); p.entry4hRegime=o.optString("entry4hRegime",""); p.target1hValid=o.optBoolean("target1hValid",false);
                    p.currentPrice=o.optDouble("currentPrice"); p.current1hSt=o.optDouble("current1hSt"); p.current1hAtr=o.optDouble("current1hAtr"); p.current1hState=o.optString("current1hState",""); p.current1hRegime=o.optString("current1hRegime","");
                    p.mfePct=o.optDouble("mfePct",0); p.maePct=o.optDouble("maePct",0);
                    p.closestStatic1hAtr=optD(o,"closestStatic1hAtr"); p.closestStatic1hPct=optD(o,"closestStatic1hPct"); p.closestDynamic1hAtr=optD(o,"closestDynamic1hAtr"); p.closestDynamic1hPct=optD(o,"closestDynamic1hPct");
                    p.nearStatic025=o.optBoolean("nearStatic025",false); p.nearStatic010=o.optBoolean("nearStatic010",false); p.static1hTouched=o.optBoolean("static1hTouched",false);
                    p.nearDynamic025=o.optBoolean("nearDynamic025",false); p.nearDynamic010=o.optBoolean("nearDynamic010",false); p.dynamic1hTouched=o.optBoolean("dynamic1hTouched",false); p.maxBeyondStatic1hAtr=o.optDouble("maxBeyondStatic1hAtr",0);
                    p.sl5Outcome=o.optString("sl5Outcome","OPEN"); p.sl15Outcome=o.optString("sl15Outcome","OPEN"); p.sl5ResolvedUtc=o.optString("sl5ResolvedUtc",""); p.sl15ResolvedUtc=o.optString("sl15ResolvedUtc","");
                    p.sl5ExitPrice=optD(o,"sl5ExitPrice"); p.sl15ExitPrice=optD(o,"sl15ExitPrice"); p.sl5ReturnPct=optD(o,"sl5ReturnPct"); p.sl15ReturnPct=optD(o,"sl15ReturnPct");
                    p.ret5m=optD(o,"ret5m"); p.ret15m=optD(o,"ret15m"); p.ret30m=optD(o,"ret30m"); p.ret1h=optD(o,"ret1h"); p.ret2h=optD(o,"ret2h"); p.ret4h=optD(o,"ret4h");
                    p.active=o.optBoolean("active",true); p.completeReason=o.optString("completeReason","");
                    if(!p.id.isEmpty())out.put(p.id,p);
                }
            }catch(Exception ignored){}
            return out;
        }
    }

    public static void saveTracks(Context c,Map<String,AlignShortPaper> m){
        synchronized(LOCK){
            try{
                JSONArray a=new JSONArray();
                for(AlignShortPaper p:m.values()){
                    JSONObject o=new JSONObject();
                    o.put("id",p.id);o.put("symbol",p.symbol);o.put("market",p.market);o.put("entryTimeUtc",p.entryTimeUtc);o.put("startedMs",p.startedMs);o.put("entry5mBarOpenMs",p.entry5mBarOpenMs);o.put("last5mBarOpenMs",p.last5mBarOpenMs);
                    o.put("entryPrice",p.entryPrice);o.put("entry5mSt",p.entry5mSt);o.put("entry15mSt",p.entry15mSt);o.put("entry1hSt",p.entry1hSt);o.put("entry5mAtr",p.entry5mAtr);o.put("entry15mAtr",p.entry15mAtr);o.put("entry1hAtr",p.entry1hAtr);
                    o.put("entry5mPrevState",p.entry5mPrevState);o.put("entry5mState",p.entry5mState);o.put("entry15mPrevState",p.entry15mPrevState);o.put("entry15mState",p.entry15mState);o.put("entry1hState",p.entry1hState);o.put("entry1hRegime",p.entry1hRegime);o.put("entry4hRegime",p.entry4hRegime);o.put("target1hValid",p.target1hValid);
                    o.put("currentPrice",p.currentPrice);o.put("current1hSt",p.current1hSt);o.put("current1hAtr",p.current1hAtr);o.put("current1hState",p.current1hState);o.put("current1hRegime",p.current1hRegime);o.put("mfePct",p.mfePct);o.put("maePct",p.maePct);
                    putD(o,"closestStatic1hAtr",p.closestStatic1hAtr);putD(o,"closestStatic1hPct",p.closestStatic1hPct);putD(o,"closestDynamic1hAtr",p.closestDynamic1hAtr);putD(o,"closestDynamic1hPct",p.closestDynamic1hPct);
                    o.put("nearStatic025",p.nearStatic025);o.put("nearStatic010",p.nearStatic010);o.put("static1hTouched",p.static1hTouched);o.put("nearDynamic025",p.nearDynamic025);o.put("nearDynamic010",p.nearDynamic010);o.put("dynamic1hTouched",p.dynamic1hTouched);o.put("maxBeyondStatic1hAtr",p.maxBeyondStatic1hAtr);
                    o.put("sl5Outcome",p.sl5Outcome);o.put("sl15Outcome",p.sl15Outcome);o.put("sl5ResolvedUtc",p.sl5ResolvedUtc);o.put("sl15ResolvedUtc",p.sl15ResolvedUtc);putD(o,"sl5ExitPrice",p.sl5ExitPrice);putD(o,"sl15ExitPrice",p.sl15ExitPrice);putD(o,"sl5ReturnPct",p.sl5ReturnPct);putD(o,"sl15ReturnPct",p.sl15ReturnPct);
                    putD(o,"ret5m",p.ret5m);putD(o,"ret15m",p.ret15m);putD(o,"ret30m",p.ret30m);putD(o,"ret1h",p.ret1h);putD(o,"ret2h",p.ret2h);putD(o,"ret4h",p.ret4h);o.put("active",p.active);o.put("completeReason",p.completeReason);a.put(o);
                }
                write(new File(c.getFilesDir(),TRACK),a.toString());
            }catch(Exception ignored){}
        }
    }

    public static void appendAlert(Context c,AlignShortPaper p){
        synchronized(LOCK){
            try{
                File f=new File(c.getFilesDir(),ALERTS);boolean fresh=!f.exists();
                try(FileOutputStream os=new FileOutputStream(f,true)){
                    if(fresh)os.write(("time_utc,symbol,market,signal,entry_price,st_5m,st_15m,st_1h,tp_near_025,tp_near_010,atr_5m,atr_15m,atr_1h,one_hour_target_valid,one_hour_state,one_hour_regime,four_hour_regime,bar_open_ms\n").getBytes(StandardCharsets.UTF_8));
                    String s=q(p.entryTimeUtc)+","+q(p.symbol)+","+q(p.market)+","+q("15m BEAR already + 5m fresh BEAR flip")+","+p.entryPrice+","+p.entry5mSt+","+p.entry15mSt+","+p.entry1hSt+","+p.tpNear025Price()+","+p.tpNear010Price()+","+p.entry5mAtr+","+p.entry15mAtr+","+p.entry1hAtr+","+p.target1hValid+","+q(p.entry1hState)+","+q(p.entry1hRegime)+","+q(p.entry4hRegime)+","+p.entry5mBarOpenMs+"\n";
                    os.write(s.getBytes(StandardCharsets.UTF_8));
                }
            }catch(Exception ignored){}
        }
    }

    public static String readAlertCsv(Context c){
        try{File f=new File(c.getFilesDir(),ALERTS);return f.exists()?read(f):"time_utc,symbol,market,signal,entry_price,st_5m,st_15m,st_1h,tp_near_025,tp_near_010,atr_5m,atr_15m,atr_1h,one_hour_target_valid,one_hour_state,one_hour_regime,four_hour_regime,bar_open_ms\n";}catch(Exception e){return "";}
    }

    public static String trackCsv(Map<String,AlignShortPaper> m){
        StringBuilder b=new StringBuilder("id,symbol,market,entry_time_utc,entry_bar_open_ms,entry_price,entry_5m_st,entry_15m_st,entry_1h_st,tp_near_025,tp_near_010,entry_5m_atr,entry_15m_atr,entry_1h_atr,entry_5m_prev_state,entry_5m_state,entry_15m_prev_state,entry_15m_state,entry_1h_state,entry_1h_regime,entry_4h_regime,target_1h_valid,sl5_risk_pct,sl15_risk_pct,target_reward_pct,rr_sl5,rr_sl15,current_price,short_return_pct,mfe_pct,mae_pct,mfe_atr5,mae_atr5,current_1h_st,current_1h_atr,current_1h_state,current_1h_regime,closest_static_1h_atr,closest_static_1h_pct,near_static_025,near_static_010,static_1h_touched,max_beyond_static_1h_atr,closest_dynamic_1h_atr,closest_dynamic_1h_pct,near_dynamic_025,near_dynamic_010,dynamic_1h_touched,sl5_outcome,sl5_resolved_utc,sl5_exit_price,sl5_return_pct,sl15_outcome,sl15_resolved_utc,sl15_exit_price,sl15_return_pct,ret_5m_pct,ret_15m_pct,ret_30m_pct,ret_1h_pct,ret_2h_pct,ret_4h_pct,status,complete_reason\n");
        for(AlignShortPaper p:m.values()){
            b.append(q(p.id)).append(',').append(q(p.symbol)).append(',').append(q(p.market)).append(',').append(q(p.entryTimeUtc)).append(',').append(p.entry5mBarOpenMs).append(',').append(p.entryPrice).append(',').append(p.entry5mSt).append(',').append(p.entry15mSt).append(',').append(p.entry1hSt).append(',').append(num(p.tpNear025Price())).append(',').append(num(p.tpNear010Price())).append(',').append(p.entry5mAtr).append(',').append(p.entry15mAtr).append(',').append(p.entry1hAtr).append(',').append(q(p.entry5mPrevState)).append(',').append(q(p.entry5mState)).append(',').append(q(p.entry15mPrevState)).append(',').append(q(p.entry15mState)).append(',').append(q(p.entry1hState)).append(',').append(q(p.entry1hRegime)).append(',').append(q(p.entry4hRegime)).append(',').append(p.target1hValid).append(',').append(num(p.sl5RiskPct())).append(',').append(num(p.sl15RiskPct())).append(',').append(num(p.target1hRewardPct())).append(',').append(num(p.rr5())).append(',').append(num(p.rr15())).append(',').append(p.currentPrice).append(',').append(p.returnPct()).append(',').append(p.mfePct).append(',').append(p.maePct).append(',').append(num(p.mfeAtr5())).append(',').append(num(p.maeAtr5())).append(',').append(p.current1hSt).append(',').append(p.current1hAtr).append(',').append(q(p.current1hState)).append(',').append(q(p.current1hRegime)).append(',').append(csvD(p.closestStatic1hAtr)).append(',').append(csvD(p.closestStatic1hPct)).append(',').append(p.nearStatic025).append(',').append(p.nearStatic010).append(',').append(p.static1hTouched).append(',').append(p.maxBeyondStatic1hAtr).append(',').append(csvD(p.closestDynamic1hAtr)).append(',').append(csvD(p.closestDynamic1hPct)).append(',').append(p.nearDynamic025).append(',').append(p.nearDynamic010).append(',').append(p.dynamic1hTouched).append(',').append(q(p.sl5Outcome)).append(',').append(q(p.sl5ResolvedUtc)).append(',').append(csvD(p.sl5ExitPrice)).append(',').append(csvD(p.sl5ReturnPct)).append(',').append(q(p.sl15Outcome)).append(',').append(q(p.sl15ResolvedUtc)).append(',').append(csvD(p.sl15ExitPrice)).append(',').append(csvD(p.sl15ReturnPct)).append(',').append(csvD(p.ret5m)).append(',').append(csvD(p.ret15m)).append(',').append(csvD(p.ret30m)).append(',').append(csvD(p.ret1h)).append(',').append(csvD(p.ret2h)).append(',').append(csvD(p.ret4h)).append(',').append(p.active?"TRACKING":"COMPLETE").append(',').append(q(p.completeReason)).append('\n');
        }
        return b.toString();
    }

    public static Uri exportToDownloads(Context c,String name,String content)throws Exception{
        ContentValues v=new ContentValues();v.put(MediaStore.MediaColumns.DISPLAY_NAME,name);v.put(MediaStore.MediaColumns.MIME_TYPE,"text/csv");v.put(MediaStore.MediaColumns.RELATIVE_PATH,"Download/STBearAlignLab");
        Uri u=c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(u==null)throw new IOException("create export failed");
        try(OutputStream os=c.getContentResolver().openOutputStream(u)){os.write(content.getBytes(StandardCharsets.UTF_8));}
        return u;
    }

    private static Double optD(JSONObject o,String k){if(!o.has(k)||o.isNull(k))return null;double v=o.optDouble(k,Double.NaN);return Double.isFinite(v)?v:null;}
    private static void putD(JSONObject o,String k,Double v)throws JSONException{if(v==null||!Double.isFinite(v))o.put(k,JSONObject.NULL);else o.put(k,v);}
    private static String csvD(Double v){return v==null||!Double.isFinite(v)?"":String.valueOf(v);}
    private static String num(double v){return Double.isFinite(v)?String.valueOf(v):"";}
    private static String q(String s){if(s==null)return "";return "\""+s.replace("\"","\"\"")+"\"";}
    private static String read(File f)throws Exception{try(FileInputStream in=new FileInputStream(f);ByteArrayOutputStream o=new ByteArrayOutputStream()){byte[]b=new byte[8192];int n;while((n=in.read(b))>0)o.write(b,0,n);return o.toString("UTF-8");}}
    private static void write(File f,String s)throws Exception{try(FileOutputStream o=new FileOutputStream(f)){o.write(s.getBytes(StandardCharsets.UTF_8));}}
}
